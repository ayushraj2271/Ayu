@file:OptIn(ExperimentalMaterial3Api::class)
package com.ayu.pdfoffice.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.navigation.NavHostController
import com.ayu.pdfoffice.data.FileUtil
import com.ayu.pdfoffice.data.Pending
import com.ayu.pdfoffice.data.Store
import com.ayu.pdfoffice.data.Thumbs
import com.ayu.pdfoffice.pdf.BitmapCache
import com.ayu.pdfoffice.pdf.PdfOps
import com.ayu.pdfoffice.pdf.PdfSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val invertFilter = ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
    -1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f)))

@Composable
fun ViewerScreen(uri: Uri, nav: NavHostController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("Document") }
    var file by remember { mutableStateOf<File?>(null) }
    var src by remember { mutableStateOf<PdfSource?>(null) }
    var sizes by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    val holder = remember { arrayOfNulls<PdfSource>(1) }

    LaunchedEffect(uri) {
        try {
            val r = withContext(Dispatchers.IO) {
                val m = FileUtil.meta(ctx, uri)
                val f = FileUtil.copyToCache(ctx, uri, m.name)
                val s = PdfSource(f)
                holder[0] = s
                if (s.pageCount == 0) throw IllegalStateException("empty")
                val sz = List(s.pageCount) { s.size(it) }
                Thumbs.save(ctx, uri.toString(), s.render(0, 240))
                Triple(m, f, s) to sz
            }
            name = r.first.first.name; file = r.first.second; src = r.first.third; sizes = r.second
            Store.touch(uri.toString(), r.first.first.name, r.first.first.size)
        } catch (e: SecurityException) {
            error = "This PDF is password-protected. Use Protect PDF → Remove security (with the password) to make an unlocked copy, then open that copy."
        } catch (e: Throwable) {
            error = "AYU PDF Office couldn't open this PDF. It may be damaged or use a format Android can't render."
        }
    }
    DisposableEffect(Unit) { onDispose { holder[0]?.close() } }

    var zoom by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableIntStateOf(0) }
    var immersive by remember { mutableStateOf(false) }
    val dark = isDarkApp()
    var invert by remember { mutableStateOf(dark) }
    var sheet by remember { mutableStateOf<String?>(null) }
    var goto by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val hits = remember { mutableStateListOf<PdfOps.Hit>() }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var searchStatus by remember { mutableStateOf("") }
    var bookmarks by remember { mutableStateOf(Store.bookmarks(uri.toString())) }
    val listState = rememberLazyListState()
    val current by remember { derivedStateOf { listState.firstVisibleItemIndex } }
    val flow = rememberSaveFlow(onError = { error = it })

    // Full screen = hide system bars and toolbars.
    val view = LocalView.current
    LaunchedEffect(immersive) {
        val w = ctx.activity()?.window ?: return@LaunchedEffect
        val c = WindowCompat.getInsetsController(w, view)
        if (immersive) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }
    DisposableEffect(Unit) {
        onDispose { ctx.activity()?.window?.let { WindowCompat.getInsetsController(it, view).show(WindowInsetsCompat.Type.systemBars()) } }
    }
    BackHandler(immersive || searching) { if (searching) { searching = false; searchJob?.cancel() } else immersive = false }

    fun doSearch() {
        searchJob?.cancel(); hits.clear()
        val f = file ?: return
        if (query.isBlank()) return
        searchJob = scope.launch {
            searchStatus = "Searching…"
            try {
                withContext(Dispatchers.IO) {
                    PdfOps.search(f, query.trim(), { !isActive }, { p, n -> searchStatus = "Searching page $p of $n…" }) { h -> if (hits.size < 300) hits.add(h) }
                }
                searchStatus = if (hits.isEmpty()) "No matches. Scanned (image-only) PDFs have no searchable text." else "${hits.size} match(es)"
            } catch (e: Throwable) { searchStatus = "Search failed: ${PdfOps.friendly(e)}" }
        }
    }
    fun jump(p: Int) { scope.launch { listState.scrollToItem(p.coerceIn(0, (sizes.size - 1).coerceAtLeast(0))) } }
    fun openTool(route: String) { Pending.uri = uri; nav.navigate(route) }

    Scaffold(
        topBar = {
            if (!immersive) TopAppBar(
                navigationIcon = { IconButton({ if (searching) { searching = false; searchJob?.cancel() } else nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                title = {
                    if (searching) OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Search text") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                        modifier = Modifier.fillMaxWidth())
                    else Text(name, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                },
                actions = {
                    if (!searching) IconButton({ searching = true }, enabled = file != null) { Icon(Icons.Default.Search, "Search") }
                    IconButton({ bookmarks = Store.toggleBookmark(uri.toString(), current) }, enabled = file != null) {
                        Icon(if (current in bookmarks) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark this page")
                    }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "More") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("Share") }, { menu = false; file?.let { FileUtil.shareFile(ctx, it) } })
                            DropdownMenuItem({ Text("Print") }, { menu = false; file?.let { FileUtil.print(ctx.activity() ?: ctx, it, name) } })
                            DropdownMenuItem({ Text("Save a copy…") }, { menu = false; file?.let { flow.start(it) } })
                            DropdownMenuItem({ Text("Go to page…") }, { menu = false; goto = true })
                            DropdownMenuItem({ Text("Fit width") }, { menu = false; zoom = 1f })
                            DropdownMenuItem({ Text("Fit page") }, { menu = false
                                sizes.getOrNull(current)?.let { (w, h) ->
                                    val asp = if (rotation % 180 == 0) h.toFloat() / w else w.toFloat() / h
                                    zoom = (0.85f / asp).coerceIn(0.4f, 1f) } })
                            DropdownMenuItem({ Text("Rotate view") }, { menu = false; rotation = (rotation + 90) % 360 })
                            DropdownMenuItem({ Text("Full screen") }, { menu = false; immersive = true })
                            DropdownMenuItem({ Text(if (invert) "Light reading mode" else "Dark reading mode") }, { menu = false; invert = !invert })
                        }
                    }
                })
        },
        bottomBar = {
            if (!immersive && !searching) NavigationBar {
                NavigationBarItem(false, { sheet = "pages" }, { Icon(Icons.Default.ViewModule, null) }, label = { Text("Pages") }, enabled = file != null)
                NavigationBarItem(false, { openTool("editor/annotate") }, { Icon(Icons.Default.Brush, null) }, label = { Text("Annotate") }, enabled = file != null)
                NavigationBarItem(false, { openTool("organize") }, { Icon(Icons.Default.Layers, null) }, label = { Text("Edit") }, enabled = file != null)
                NavigationBarItem(false, { openTool("editor/sign") }, { Icon(Icons.Default.Gesture, null) }, label = { Text("Sign") }, enabled = file != null)
                NavigationBarItem(false, { sheet = "tools" }, { Icon(Icons.Default.Build, null) }, label = { Text("Tools") }, enabled = file != null)
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(if (invert) Color(0xFF202124) else MaterialTheme.colorScheme.surfaceVariant)) {
            val s = src
            when {
                error != null -> Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center) { Text(error!!) }
                s == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> BoxWithConstraints(Modifier.fillMaxSize()
                    // Two-finger pinch is handled in the Initial pass so the list doesn't scroll while zooming.
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            do {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                if (ev.changes.size > 1) {
                                    zoom = (zoom * ev.calculateZoom()).coerceIn(0.4f, 4f)
                                    ev.changes.forEach { it.consume() }
                                }
                            } while (ev.changes.any { it.pressed })
                        }
                    }
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 2f }) }
                ) {
                    val vw = maxWidth
                    val density = LocalDensity.current
                    Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
                        LazyColumn(Modifier.width(vw * maxOf(zoom, 1f)).fillMaxHeight(), state = listState,
                            contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(sizes) { i, sz ->
                                val (w, h) = sz
                                val aspect = if (rotation % 180 == 0) w.toFloat() / h else h.toFloat() / w
                                val pageW = vw * zoom - 16.dp
                                val px = with(density) { pageW.roundToPx() }.let { (it / 200) * 200 }.coerceIn(200, 2400)
                                val bmp by produceState<Bitmap?>(null, i, px, rotation) {
                                    value = try { BitmapCache.get(s, i, px, rotation) } catch (e: Exception) { null }
                                }
                                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                                    Box(Modifier.width(pageW.coerceAtLeast(40.dp)).aspectRatio(aspect).background(Color.White)) {
                                        bmp?.let { Image(it.asImageBitmap(), "Page ${i + 1}", Modifier.fillMaxSize(),
                                            contentScale = ContentScale.FillBounds, colorFilter = if (invert) invertFilter else null) }
                                            ?: CircularProgressIndicator(Modifier.align(Alignment.Center))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (sizes.isNotEmpty() && !searching) AssistChip({ goto = true }, { Text("${current + 1} / ${sizes.size}") },
                modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp))
            if (immersive) IconButton({ immersive = false }, Modifier.align(Alignment.TopEnd)) { Icon(Icons.Default.FullscreenExit, "Exit full screen") }
            if (searching) Surface(Modifier.fillMaxSize()) {
                Column {
                    Text(searchStatus, Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
                    LazyColumn {
                        itemsIndexed(hits) { _, h ->
                            ListItem(headlineContent = { Text("Page ${h.page + 1}") }, supportingContent = { Text(h.snippet) },
                                modifier = Modifier.clickable { searching = false; searchJob?.cancel(); jump(h.page) })
                        }
                    }
                }
            }
        }
    }

    if (goto) {
        var t by remember { mutableStateOf("") }
        AlertDialog({ goto = false }, title = { Text("Go to page (1–${sizes.size})") },
            text = { OutlinedTextField(t, { t = it.filter(Char::isDigit) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) },
            confirmButton = { TextButton({ goto = false; t.toIntOrNull()?.let { jump(it - 1) } }) { Text("Go") } },
            dismissButton = { TextButton({ goto = false }) { Text("Cancel") } })
    }

    if (sheet != null && src != null) ModalBottomSheet({ sheet = null }) {
        val s = src!!
        if (sheet == "pages") {
            var onlyBm by remember { mutableStateOf(false) }
            FilterChip(onlyBm, { onlyBm = !onlyBm }, { Text("Bookmarked only") }, Modifier.padding(horizontal = 16.dp))
            val pages = (0 until s.pageCount).filter { !onlyBm || it in bookmarks }
            LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.fillMaxHeight(0.7f), contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(pages) { i ->
                    val bmp by produceState<Bitmap?>(null, i) { value = try { BitmapCache.get(s, i, 220) } catch (e: Exception) { null } }
                    Column(Modifier.clickable { sheet = null; jump(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.fillMaxWidth().aspectRatio(0.72f).background(Color.White)) {
                            bmp?.let { Image(it.asImageBitmap(), "Page ${i + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                            if (i in bookmarks) Icon(Icons.Default.Bookmark, null, Modifier.align(Alignment.TopEnd), tint = MaterialTheme.colorScheme.primary)
                        }
                        Text("${i + 1}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        } else {
            listOf("Compress" to "compress", "Split / extract" to "split", "Protect / unlock" to "protect", "Watermark" to "watermark",
                "Redact" to "editor/redact", "PDF → Image" to "pdf2img", "PDF → Text" to "pdf2text", "Merge with other PDFs" to "merge")
                .forEach { (l, r) -> ListItem(headlineContent = { Text(l) }, modifier = Modifier.clickable { sheet = null; openTool(r) }) }
            Spacer(Modifier.height(24.dp))
        }
    }
    SavedDialog(flow, null)
}
