package com.ayu.pdfoffice.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** A document the user has opened or saved through the app (the "library"). */
data class Doc(val uri: String, val name: String, val size: Long, val opened: Long, val fav: Boolean)

/** One-shot hand-off: the viewer sets this before opening a tool for the current file. */
object Pending {
    var uri: Uri? = null
    fun take(): Uri? { val u = uri; uri = null; return u }
}

/** Settings + library, backed by SharedPreferences. Everything stays on the device. */
object Store {
    private lateinit var sp: SharedPreferences
    var theme by mutableIntStateOf(0)          // 0 system, 1 light, 2 dark
    var accent by mutableIntStateOf(0)
    var confirmDelete by mutableStateOf(true)
    var compression by mutableIntStateOf(1)    // 0 low, 1 medium, 2 high
    var sort by mutableIntStateOf(0)           // 0 recent, 1 name, 2 size
    var onboarded by mutableStateOf(false)
    val docs = mutableStateListOf<Doc>()

    fun init(c: Context) {
        sp = c.getSharedPreferences("ayu", Context.MODE_PRIVATE)
        theme = sp.getInt("theme", 0)
        accent = sp.getInt("accent", 0)
        confirmDelete = sp.getBoolean("confirmDelete", true)
        compression = sp.getInt("compression", 1)
        sort = sp.getInt("sort", 0)
        onboarded = sp.getBoolean("onboarded", false)
        runCatching {
            val a = JSONArray(sp.getString("docs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                docs.add(Doc(o.getString("u"), o.getString("n"), o.optLong("s"), o.optLong("t"), o.optBoolean("f")))
            }
        }
    }

    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun updateAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun updateConfirmDelete(v: Boolean) { confirmDelete = v; sp.edit().putBoolean("confirmDelete", v).apply() }
    fun updateCompression(v: Int) { compression = v; sp.edit().putInt("compression", v).apply() }
    fun updateSort(v: Int) { sort = v; sp.edit().putInt("sort", v).apply() }
    fun finishOnboarding() { onboarded = true; sp.edit().putBoolean("onboarded", true).apply() }

    fun touch(uri: String, name: String, size: Long) {
        val old = docs.firstOrNull { it.uri == uri }
        docs.removeAll { it.uri == uri }
        docs.add(0, Doc(uri, name, size, System.currentTimeMillis(), old?.fav ?: false))
        while (docs.size > 200) docs.removeAt(docs.lastIndex)
        save()
    }

    fun toggleFav(uri: String) {
        val i = docs.indexOfFirst { it.uri == uri }
        if (i >= 0) { docs[i] = docs[i].copy(fav = !docs[i].fav); save() }
    }

    fun remove(uri: String) { docs.removeAll { it.uri == uri }; save() }

    fun renamed(old: String, new: Uri?, name: String) {
        val i = docs.indexOfFirst { it.uri == old }
        if (i >= 0) { docs[i] = docs[i].copy(uri = new?.toString() ?: old, name = name); save() }
    }

    fun bookmarks(uri: String): Set<Int> =
        (sp.getStringSet("bm_${uri.hashCode()}", emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()

    fun toggleBookmark(uri: String, page: Int): Set<Int> {
        val cur = bookmarks(uri).toMutableSet()
        if (!cur.add(page)) cur.remove(page)
        sp.edit().putStringSet("bm_${uri.hashCode()}", cur.map { it.toString() }.toSet()).apply()
        return cur
    }

    private fun save() {
        val a = JSONArray()
        docs.forEach { a.put(JSONObject().put("u", it.uri).put("n", it.name).put("s", it.size).put("t", it.opened).put("f", it.fav)) }
        sp.edit().putString("docs", a.toString()).apply()
    }
}
