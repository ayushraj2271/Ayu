@file:OptIn(ExperimentalMaterial3Api::class)
package com.ayu.pdfoffice.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.DocumentsContract
import android.text.format.DateUtils
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.ayu.pdfoffice.data.Doc
import com.ayu.pdfoffice.data.FileUtil
import com.ayu.pdfoffice.data.Store
import com.ayu.pdfoffice.data.Thumbs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

const val NO_ENGINE = "This conversion requires a document engine that isn't available in this build."

class ToolDef(val title: String, val icon: ImageVector, val route: String?, val unavailable: String? = null)

val quickTools = listOf(
    ToolDef("Open PDF", Icons.Default.FolderOpen, "open"),
    ToolDef("Edit PDF", Icons.Default.Edit, "editor/annotate"),
    ToolDef("Merge PDF", Icons.Default.MergeType, "merge"),
    ToolDef("Split PDF", Icons.Default.CallSplit, "split"),
    ToolDef("Compress PDF", Icons.Default.Compress, "compress"),
    ToolDef("PDF → Word", Icons.Default.Description, null, NO_ENGINE),
    ToolDef("Word → PDF", Icons.Default.PictureAsPdf, null, NO_ENGINE),
    ToolDef("Image → PDF", Icons.Default.Image, "img2pdf"),
    ToolDef("PDF → Image", Icons.Default.PhotoLibrary, "pdf2img"),
    ToolDef("Scan Document", Icons.Default.DocumentScanner, "scan"),
    ToolDef("Sign PDF", Icons.Default.Gesture, "editor/sign"),
    ToolDef("Protect PDF", Icons.Default.Lock, "protect"),
)

val allTools = listOf(
    ToolDef("Edit PDF", Icons.Default.Edit, "editor/annotate"),
    ToolDef("Merge", Icons.Default.MergeType, "merge"),
    ToolDef("Split", Icons.Default.CallSplit, "split"),
    ToolDef("Compress", Icons.Default.Compress, "compress"),
    ToolDef("Convert", Icons.Default.SwapHoriz, "convert"),
    ToolDef("Scan", Icons.Default.DocumentScanner, "scan"),
    ToolDef("Sign", Icons.Default.Gesture, "editor/sign"),
    ToolDef("Fill & Sign", Icons.Default.TextFields, "editor/fill"),
    ToolDef("Protect", Icons.Default.Lock, "protect"),
    ToolDef("Watermark", Icons.Default.BrandingWatermark, "watermark"),
    ToolDef("Redact", Icons.Default.VisibilityOff, "editor/redact"),
    ToolDef("Organize Pages", Icons.Default.Layers, "organize"),
)

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.PictureAsPdf, null, Modifier.size(96.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(24.dp))
        Text("Welcome to AYU PDF Office", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Powerful PDF tools. Simple. Private.", style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text("Your PDF. Your Documents. Your Control.", style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Button(onStart, Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Get Started") }
    }
}

@Composable
fun MainScreen(nav: NavHostController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var favOnly by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val open = rememberPdfPicker { nav.openPdf(it) }
    val tabs = listOf("Home" to Icons.Default.Home, "Files" to Icons.Default.Folder, "Tools" to Icons.Default.Build,
        "Recent" to Icons.Default.History, "Settings" to Icons.Default.Settings)
    Scaffold(
        topBar = {
            if (tab == 0) TopAppBar(
                title = { Text("AYU PDF Office", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton({ tab = 1 }) { Icon(Icons.Default.Search, "Search") }
                    IconButton({ tab = 4 }) { Icon(Icons.Default.Settings, "Settings") }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "More") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("Privacy") }, { menu = false; nav.navigate("info/privacy") })
                            DropdownMenuItem({ Text("About") }, { menu = false; nav.navigate("info/about") })
                        }
                    }
                })
            else TopAppBar(title = { Text(tabs[tab].first) })
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, null) }, label = { Text(l) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeTab(nav, open, onFav = { favOnly = true; tab = 1 })
                1 -> FilesTab(nav, open, favOnly, { favOnly = it }, sortByOpened = false)
                2 -> ToolsTab(nav)
                3 -> FilesTab(nav, open, false, {}, sortByOpened = true)
                else -> SettingsTab(nav)
            }
        }
    }
}

@Composable
private fun ToolCard(t: ToolDef, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.heightIn(min = 88.dp).alpha(if (t.unavailable != null) 0.5f else 1f).clickable(onClick = onClick)) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(t.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(6.dp))
            Text(t.title, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun ToolGrid(nav: NavHostController, tools: List<ToolDef>, open: () -> Unit) {
    var info by remember { mutableStateOf<String?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        tools.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { t ->
                    ToolCard(t, Modifier.weight(1f)) {
                        when {
                            t.unavailable != null -> info = t.unavailable
                            t.route == "open" -> open()
                            else -> nav.navigate(t.route!!)
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
    info?.let { AlertDialog({ info = null }, { TextButton({ info = null }) { Text("OK") } }, title = { Text("Not available") }, text = { Text(it) }) }
}

@Composable
private fun HomeTab(nav: NavHostController, open: () -> Unit, onFav: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        item { SectionTitle("Quick Actions"); ToolGrid(nav, quickTools, open) }
        item { SectionTitle("Recent Documents") }
        if (Store.docs.isEmpty()) item { EmptyDocs(nav, open) }
        else items(Store.docs.take(5), key = { it.uri }) { DocRow(it, nav) }
        item {
            SectionTitle("Categories")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip({ }, { Text("PDFs (${Store.docs.size})") }, leadingIcon = { Icon(Icons.Default.PictureAsPdf, null) })
                AssistChip(onFav, { Text("Favorites (${Store.docs.count { it.fav }})") }, leadingIcon = { Icon(Icons.Default.Star, null) })
            }
            Text("Other document types (Word, spreadsheets, presentations) can't be opened in this build.",
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun EmptyDocs(nav: NavHostController, open: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Description, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(8.dp))
        Text("No documents yet", style = MaterialTheme.typography.titleMedium)
        Text("Open a PDF or create your first document.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(open) { Text("Open PDF") }
            OutlinedButton({ nav.navigate("img2pdf") }) { Text("Create PDF") }
        }
    }
}

@Composable
private fun FilesTab(nav: NavHostController, open: () -> Unit, favOnly: Boolean, setFav: (Boolean) -> Unit, sortByOpened: Boolean) {
    var q by remember { mutableStateOf("") }
    val base = Store.docs.filter { (!favOnly || it.fav) && it.name.contains(q, true) }
    val list = when {
        sortByOpened -> base.sortedByDescending { it.opened }
        Store.sort == 1 -> base.sortedBy { it.name.lowercase() }
        Store.sort == 2 -> base.sortedByDescending { it.size }
        else -> base
    }
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
        item {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                placeholder = { Text("Search by file name") }, leadingIcon = { Icon(Icons.Default.Search, null) })
            if (!sortByOpened) Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!favOnly, { setFav(false) }, { Text("All PDFs") })
                FilterChip(favOnly, { setFav(true) }, { Text("Favorites") })
            }
            Text("Shows documents you opened or saved with AYU PDF Office. Use Open PDF to add files from anywhere on your device.",
                style = MaterialTheme.typography.bodySmall)
            TextButton(open) { Text("Open PDF…") }
        }
        if (list.isEmpty()) item { EmptyDocs(nav, open) } else items(list, key = { it.uri }) { DocRow(it, nav) }
    }
}

@Composable
private fun ToolsTab(nav: NavHostController) {
    LazyColumn(contentPadding = PaddingValues(16.dp)) { item { ToolGrid(nav, allTools) { } } }
}

@Composable
fun DocRow(d: Doc, nav: NavHostController) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var newName by remember { mutableStateOf(d.name) }
    val uri = Uri.parse(d.uri)
    val thumb by produceState<Bitmap?>(null, d.uri) { value = withContext(Dispatchers.IO) { Thumbs.load(ctx, d.uri) } }
    Row(Modifier.fillMaxWidth().clickable { nav.openPdf(uri) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp, 64.dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                ?: Icon(Icons.Default.PictureAsPdf, null)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(d.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text("PDF · ${FileUtil.size(d.size)} · ${DateUtils.getRelativeTimeSpanString(d.opened, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)}",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (d.fav) Icon(Icons.Default.Star, "Favorite", tint = MaterialTheme.colorScheme.primary)
        Box {
            IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "More options for ${d.name}") }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem({ Text("Open") }, { menu = false; nav.openPdf(uri) })
                DropdownMenuItem({ Text("Rename") }, { menu = false; newName = d.name; dialog = "rename" })
                DropdownMenuItem({ Text("Share") }, { menu = false; runCatching { FileUtil.shareUri(ctx, uri) } })
                DropdownMenuItem({ Text(if (d.fav) "Remove favorite" else "Favorite") }, { menu = false; Store.toggleFav(d.uri) })
                DropdownMenuItem({ Text("Details") }, { menu = false; dialog = "details" })
                DropdownMenuItem({ Text("Remove from list") }, { menu = false; Store.remove(d.uri) })
                DropdownMenuItem({ Text("Delete file…") }, { menu = false; if (Store.confirmDelete) dialog = "delete" else deleteFile(ctx, d) })
            }
        }
    }
    when (dialog) {
        "rename" -> AlertDialog({ dialog = null }, title = { Text("Rename") },
            text = { OutlinedTextField(newName, { newName = it }, singleLine = true) },
            confirmButton = {
                TextButton({
                    dialog = null
                    try {
                        val n = DocumentsContract.renameDocument(ctx.contentResolver, uri, newName)
                        if (n != null) { Store.renamed(d.uri, n, newName); Toast.makeText(ctx, "Renamed", Toast.LENGTH_SHORT).show() }
                        else Toast.makeText(ctx, "This location doesn't allow renaming.", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) { Toast.makeText(ctx, "Couldn't rename: this location may be read-only.", Toast.LENGTH_LONG).show() }
                }) { Text("Rename") }
            }, dismissButton = { TextButton({ dialog = null }) { Text("Cancel") } })
        "delete" -> AlertDialog({ dialog = null }, title = { Text("Delete this file?") },
            text = { Text("${d.name} will be permanently deleted from your device.") },
            confirmButton = { TextButton({ dialog = null; deleteFile(ctx, d) }) { Text("Delete") } },
            dismissButton = { TextButton({ dialog = null }) { Text("Cancel") } })
        "details" -> {
            val meta by produceState<FileUtil.Meta?>(null) { value = withContext(Dispatchers.IO) { FileUtil.meta(ctx, uri) } }
            val pages by produceState<Int?>(null) {
                value = withContext(Dispatchers.IO) {
                    runCatching { ctx.contentResolver.openFileDescriptor(uri, "r")?.use { PdfRenderer(it).run { pageCount.also { close() } } } }.getOrNull()
                }
            }
            AlertDialog({ dialog = null }, title = { Text("Details") }, confirmButton = { TextButton({ dialog = null }) { Text("Close") } },
                text = {
                    Column {
                        Text("Name: ${d.name}"); Text("Type: PDF document")
                        Text("Size: ${FileUtil.size(meta?.size ?: d.size)}")
                        Text("Location: ${uri.authority}${uri.path?.let { p -> "  " + Uri.decode(p) } ?: ""}")
                        meta?.modified?.takeIf { it > 0 }?.let { Text("Modified: ${DateUtils.formatDateTime(ctx, it, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME)}") }
                        pages?.let { Text("Pages: $it") }
                    }
                })
        }
    }
}

private fun deleteFile(ctx: android.content.Context, d: Doc) {
    try {
        if (DocumentsContract.deleteDocument(ctx.contentResolver, Uri.parse(d.uri))) {
            Store.remove(d.uri); Toast.makeText(ctx, "File deleted", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(ctx, "Couldn't delete this file.", Toast.LENGTH_LONG).show()
    } catch (e: Exception) { Toast.makeText(ctx, "Couldn't delete: this location doesn't allow it.", Toast.LENGTH_LONG).show() }
}

@Composable
private fun SettingsTab(nav: NavHostController) {
    val ctx = LocalContext.current
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0" }
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        item {
            SectionTitle("Appearance")
            ChipRow(listOf("System default", "Light", "Dark"), Store.theme) { Store.updateTheme(it) }
            Spacer(Modifier.height(8.dp)); Text("Accent colour", style = MaterialTheme.typography.bodyMedium)
            Row {
                Accents.forEachIndexed { i, c ->
                    Box(Modifier.size(48.dp).padding(8.dp).clip(CircleShape).background(c).clickable { Store.updateAccent(i) }, contentAlignment = Alignment.Center) {
                        if (Store.accent == i) Icon(Icons.Default.Check, AccentNames[i], tint = androidx.compose.ui.graphics.Color.White)
                    }
                }
            }
            SectionTitle("PDF")
            Text("Default compression quality", style = MaterialTheme.typography.bodyMedium)
            ChipRow(listOf("Low (best quality)", "Medium", "High (smallest)"), Store.compression) { Store.updateCompression(it) }
            SectionTitle("Files")
            Text("Sort order in Files", style = MaterialTheme.typography.bodyMedium)
            ChipRow(listOf("Recently opened", "Name", "Size"), Store.sort) { Store.updateSort(it) }
            SectionTitle("Safety")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Confirm before deleting files", Modifier.weight(1f))
                Switch(Store.confirmDelete, { Store.updateConfirmDelete(it) })
            }
            SectionTitle("Privacy & About")
            ListItem(headlineContent = { Text("Privacy") }, modifier = Modifier.clickable { nav.navigate("info/privacy") })
            ListItem(headlineContent = { Text("Privacy policy & Terms") }, modifier = Modifier.clickable { nav.navigate("info/terms") })
            ListItem(headlineContent = { Text("Open-source licenses") }, modifier = Modifier.clickable { nav.navigate("info/licenses") })
            ListItem(headlineContent = { Text("About AYU PDF Office") }, supportingContent = { Text("Version $version") },
                modifier = Modifier.clickable { nav.navigate("info/about") })
        }
    }
}

@Composable
fun InfoScreen(nav: NavHostController, page: String) {
    val (title, body) = when (page) {
        "privacy" -> "Privacy" to """• Files are processed on your device whenever possible.
• No account, login or cloud service is used or required.
• No document is uploaded unless you choose to share or export it.
• There is no AI analysis of your documents.
• The app requests no storage, camera, contacts or location permission. Files are opened and saved through the Android file picker; scanning uses the system document-scanner screen (Google Play services), which processes images on-device.
• The app keeps only a small list of recently opened files, bookmarks and your settings, stored privately on this device."""
        "terms" -> "Privacy policy & Terms" to """AYU PDF Office is provided "as is", without warranty of any kind. You are responsible for keeping backups of your documents. Always review exported files before sharing them; redaction and conversion results should be verified.

A visual signature placed with this app is an image on the page. It is NOT a cryptographic digital-certificate signature and does not provide the legal or technical guarantees of one.

(Placeholder text – have it reviewed for your jurisdiction before publishing.)"""
        "licenses" -> "Open-source licenses" to """• Apache PDFBox – Apache License 2.0
• PdfBox-Android (Tom Roush) – Apache License 2.0
• AndroidX / Jetpack Compose / Material 3 – Apache License 2.0
• Kotlin & kotlinx.coroutines – Apache License 2.0
• Google ML Kit Document Scanner – ML Kit terms (Google Play services)"""
        else -> "About" to """AYU PDF Office
Your PDF. Your Documents. Your Control.

PDF rendering: Android PdfRenderer.
PDF editing, merging, splitting, encryption and text extraction: PdfBox-Android."""
    }
    ToolScaffold(title, { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp)) { item { Text(body) } }
    }
}
