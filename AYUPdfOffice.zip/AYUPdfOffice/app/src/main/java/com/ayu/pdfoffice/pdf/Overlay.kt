package com.ayu.pdfoffice.pdf

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font

/**
 * Editable page content. Coordinates are FRACTIONS (0..1) of the displayed page, origin top-left,
 * so the same item can be drawn on screen and written into the PDF for any page size/rotation.
 * Items stay editable (move / resize / delete / undo) until the PDF is exported.
 */
sealed class Item {
    abstract val page: Int
    abstract fun moved(dx: Float, dy: Float): Item

    /** (fx,fy) is the text BASELINE-left. size is in PDF points. family: 0 Helvetica, 1 Times, 2 Courier. */
    data class Text(override val page: Int, val text: String, val fx: Float, val fy: Float, val size: Float,
                    val rgb: Int, val family: Int, val bold: Boolean) : Item() {
        override fun moved(dx: Float, dy: Float) = copy(fx = fx + dx, fy = fy + dy)
    }

    /** (fx,fy) is the top-left corner; fw is the width as a fraction of the page width. */
    data class Img(override val page: Int, val bmp: Bitmap, val fx: Float, val fy: Float, val fw: Float) : Item() {
        override fun moved(dx: Float, dy: Float) = copy(fx = fx + dx, fy = fy + dy)
    }

    data class Ink(override val page: Int, val pts: List<Pair<Float, Float>>, val rgb: Int, val width: Float, val alpha: Float) : Item() {
        override fun moved(dx: Float, dy: Float) = copy(pts = pts.map { it.first + dx to it.second + dy })
    }

    /** kind: 0 highlight (translucent fill), 1 rectangle outline, 2 redaction. */
    data class Rect(override val page: Int, val fx: Float, val fy: Float, val fw: Float, val fh: Float,
                    val kind: Int, val rgb: Int) : Item() {
        override fun moved(dx: Float, dy: Float) = copy(fx = fx + dx, fy = fy + dy)
    }
}

object Fonts {
    val names = listOf("Helvetica", "Times", "Courier")
    fun pdf(family: Int, bold: Boolean): PDType1Font = when (family) {
        1 -> if (bold) PDType1Font.TIMES_BOLD else PDType1Font.TIMES_ROMAN
        2 -> if (bold) PDType1Font.COURIER_BOLD else PDType1Font.COURIER
        else -> if (bold) PDType1Font.HELVETICA_BOLD else PDType1Font.HELVETICA
    }
    fun typeface(family: Int, bold: Boolean): Typeface = Typeface.create(
        when (family) { 1 -> Typeface.SERIF; 2 -> Typeface.MONOSPACE; else -> Typeface.SANS_SERIF },
        if (bold) Typeface.BOLD else Typeface.NORMAL)
    /** The built-in PDF fonts only cover Latin (WinAnsi) text. */
    fun encodable(family: Int, bold: Boolean, text: String) =
        try { pdf(family, bold).getStringWidth(text); true } catch (e: Exception) { false }
}

/**
 * Maps displayed-page fractions to PDF user space, handling /CropBox origin and /Rotate.
 * (rx,ry) / (ux,uy) are unit vectors of "displayed right" / "displayed up" in user space.
 */
class PageGeom(page: PDPage) {
    private val box = page.cropBox
    private val rot = ((page.rotation % 360) + 360) % 360
    private val w = box.width
    private val h = box.height
    val dispW = if (rot % 180 == 0) w else h
    val dispH = if (rot % 180 == 0) h else w
    val rx: Float; val ry: Float; val ux: Float; val uy: Float
    init {
        when (rot) {
            90 -> { rx = 0f; ry = 1f; ux = -1f; uy = 0f }
            180 -> { rx = -1f; ry = 0f; ux = 0f; uy = -1f }
            270 -> { rx = 0f; ry = -1f; ux = 1f; uy = 0f }
            else -> { rx = 1f; ry = 0f; ux = 0f; uy = 1f }
        }
    }
    fun pt(fx: Float, fy: Float): Pair<Float, Float> = when (rot) {
        90 -> (box.lowerLeftX + fy * w) to (box.lowerLeftY + fx * h)
        180 -> (box.lowerLeftX + (1 - fx) * w) to (box.lowerLeftY + fy * h)
        270 -> (box.lowerLeftX + (1 - fy) * w) to (box.lowerLeftY + (1 - fx) * h)
        else -> (box.lowerLeftX + fx * w) to (box.upperRightY - fy * h)
    }
}

/** Bounding box of an item as page fractions (used for hit-testing and the selection outline). */
fun Item.boundsFrac(dispW: Float, dispH: Float): RectF = when (this) {
    is Item.Text -> {
        val p = Paint().apply { textSize = size; typeface = Fonts.typeface(family, bold) }
        RectF(fx, fy - size / dispH, fx + p.measureText(text) / dispW, fy + 0.25f * size / dispH)
    }
    is Item.Img -> RectF(fx, fy, fx + fw, fy + fw * dispW * bmp.height / bmp.width / dispH)
    is Item.Ink -> {
        val pad = width / dispW + 0.01f
        RectF(pts.minOf { it.first } - pad, pts.minOf { it.second } - pad, pts.maxOf { it.first } + pad, pts.maxOf { it.second } + pad)
    }
    is Item.Rect -> RectF(fx, fy, fx + fw, fy + fh)
}
