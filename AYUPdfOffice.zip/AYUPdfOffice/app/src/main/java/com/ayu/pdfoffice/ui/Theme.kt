package com.ayu.pdfoffice.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.ayu.pdfoffice.data.Store

val Accents = listOf(Color(0xFFC62828), Color(0xFF1565C0), Color(0xFF2E7D32), Color(0xFF6A1B9A))
val AccentNames = listOf("Red", "Blue", "Green", "Purple")

@Composable
fun isDarkApp(): Boolean = when (Store.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }

@Composable
fun AyuTheme(content: @Composable () -> Unit) {
    val a = Accents[Store.accent.coerceIn(0, Accents.lastIndex)]
    val scheme = if (isDarkApp()) darkColorScheme(primary = a, onPrimary = Color.White)
                 else lightColorScheme(primary = a, onPrimary = Color.White)
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(small = RoundedCornerShape(8.dp), medium = RoundedCornerShape(14.dp), large = RoundedCornerShape(20.dp)),
        content = content
    )
}
