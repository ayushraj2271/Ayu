package com.ayu.pdfoffice.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import java.io.IOException
import java.io.OutputStreamWriter

class PdfError(msg: String) : Exception(msg)

/** A page in an Organize/Extract plan. src = index into the source list (-1 = new blank page). */
data class PageRef(val src: Int, val idx: Int, val rot: Int = 0)

enum class Level(val scale: Float, val quality: Int) { LOW(1f, 85), MEDIUM(0.7f, 65), HIGH(0.45f, 45) }

class WmOpts(val text: String, val size: Float, val opacity: Float, val rotation: Float, val rgb: Int, val pos: Int)

/** All PDF manipulation lives here (PdfBox-Android). Every function is blocking – call it off the main thread. */
object PdfOps {
    data class Hit(val page: Int, val snippet: String)

    // Documents are parsed with a bounded memory budget; the rest spills to temp files.
    private fun mem() = MemoryUsageSetting.setupMixed(24L * 1024 * 1024)
    fun open(file: File, password: String = ""): PDDocument = PDDocument.load(file, password, mem())
    fun pageCount(file: File, password: String = ""): Int = open(file, password).use { it.numberOfPages }

    fun friendly(e: Throwable): String = when (e) {
        is PdfError -> e.message ?: "Something went wrong."
        is IllegalArgumentException -> e.message ?: "Invalid input."
        is InvalidPasswordException -> "That password isn't correct, or the PDF is password-protected."
        is OutOfMemoryError -> "Not enough memory to finish this on this device. Try a smaller file or fewer pages."
        is IOException -> "AYU PDF Office couldn't fully process this PDF because its internal structure isn't supported." +
            (e.message?.let { " ($it)" } ?: "")
        else -> e.message ?: "Something went wrong."
    }

    // ---------------------------------------------------------------- merge / split / organize
    fun merge(files: List<File>, out: File) {
        val m = PDFMergerUtility()
        files.forEach { m.addSource(it) }
        m.destinationFileName = out.path
        m.mergeDocuments(MemoryUsageSetting.setupTempFileOnly())
    }

    /** Builds a new PDF from an arbitrary page plan: reorder, delete, duplicate, rotate, blank, cross-file insert. */
    fun build(sources: List<File>, pages: List<PageRef>, out: File) {
        if (pages.isEmpty()) throw PdfError("The result would have no pages.")
        val docs = sources.map { open(it) }
        try {
            PDDocument().use { dst ->
                for (p in pages) {
                    if (p.src < 0) {
                        val blank = PDPage(PDRectangle.A4)
                        blank.rotation = ((p.rot % 360) + 360) % 360
                        dst.addPage(blank)
                    } else {
                        // The source must stay open until dst.save(): imported pages share its content streams.
                        val imp = dst.importPage(docs[p.src].getPage(p.idx))
                        imp.rotation = (((imp.rotation + p.rot) % 360) + 360) % 360
                    }
                }
                dst.save(out)
            }
        } finally { docs.forEach { runCatching { it.close() } } }
    }

    fun extract(src: File, ranges: List<IntRange>, out: File) =
        build(listOf(src), ranges.flatMap { it.toList() }.map { PageRef(0, it) }, out)

    /** Writes one PDF per range straight into a folder chosen with the system folder picker. */
    fun splitToTree(ctx: Context, src: File, ranges: List<IntRange>, tree: Uri, base: String, progress: (Float) -> Unit): Int {
        val dir = DocumentFile.fromTreeUri(ctx, tree) ?: throw PdfError("Can't access the chosen folder.")
        val tmp = File(ctx.cacheDir, "out/split${System.nanoTime()}").apply { mkdirs() }
        try {
            open(src).use { doc ->
                ranges.forEachIndexed { i, r ->
                    val f = File(tmp, "p$i.pdf")
                    PDDocument().use { d -> r.forEach { d.importPage(doc.getPage(it)) }; d.save(f) }
                    val name = if (r.first == r.last) "${base}_p${r.first + 1}" else "${base}_p${r.first + 1}-${r.last + 1}"
                    val df = dir.createFile("application/pdf", name) ?: throw PdfError("Couldn't create files in that folder.")
                    val o = ctx.contentResolver.openOutputStream(df.uri) ?: throw PdfError("Couldn't write to that folder.")
                    o.use { out -> f.inputStream().use { it.copyTo(out) } }
                    f.delete()
                    progress((i + 1f) / ranges.size)
                }
            }
        } finally { tmp.deleteRecursively() }
        return ranges.size
    }

    // ---------------------------------------------------------------- compression
    /**
     * Re-encodes large raster images as JPEG (optionally downscaled) and keeps a new image only if
     * it is actually smaller. Images with masks/transparency are left untouched. Text-only PDFs
     * usually can't shrink this way – callers compare sizes and never claim a saving that isn't there.
     */
    fun compress(src: File, out: File, level: Level, onPage: (Int, Int) -> Unit) {
        open(src).use { doc ->
            val done = HashMap<COSBase, PDImageXObject?>()
            val n = doc.numberOfPages
            for (i in 0 until n) {
                onPage(i + 1, n)
                val res = doc.getPage(i).resources ?: continue
                for (name in res.getXObjectNames().toList()) {
                    val x = try { res.getXObject(name) } catch (e: Exception) { null }
                    if (x !is PDImageXObject) continue
                    val key = x.getCOSObject()
                    if (done.containsKey(key)) { done[key]?.let { res.put(name, it) }; continue }
                    val repl = recompress(doc, x, level)
                    done[key] = repl
                    if (repl != null) res.put(name, repl)
                }
            }
            doc.save(out)
        }
    }

    private fun recompress(doc: PDDocument, img: PDImageXObject, lv: Level): PDImageXObject? {
        return try {
            if (img.isStencil || img.softMask != null || img.mask != null) return null
            val origLen = img.getCOSObject().getInt(COSName.LENGTH, 0)
            val bmp = img.image ?: return null
            if (bmp.width * bmp.height < 200 * 200) return null
            val scaled = if (lv.scale < 1f)
                Bitmap.createScaledBitmap(bmp, (bmp.width * lv.scale).toInt().coerceAtLeast(1), (bmp.height * lv.scale).toInt().coerceAtLeast(1), true)
            else bmp
            val cand = JPEGFactory.createFromImage(doc, scaled, lv.quality / 100f)
            val newLen = cand.getCOSObject().getInt(COSName.LENGTH, 0)
            if (scaled !== bmp) scaled.recycle()
            if (origLen > 0 && newLen in 1 until origLen) cand else null
        } catch (t: Throwable) { null } // unsupported image or out of memory: keep the original
    }

    // ---------------------------------------------------------------- security
    fun protect(src: File, out: File, password: String, user: String, owner: String,
                print: Boolean, copy: Boolean, modify: Boolean, annotate: Boolean) {
        if (user.isBlank() && owner.isBlank()) throw PdfError("Enter a password.")
        open(src, password).use { doc ->
            val ap = AccessPermission().apply {
                setCanPrint(print); setCanExtractContent(copy); setCanModify(modify); setCanModifyAnnotations(annotate)
            }
            val pol = StandardProtectionPolicy(owner.ifBlank { user }, user, ap)
            pol.setEncryptionKeyLength(256)
            pol.setPreferAES(true)
            doc.protect(pol)
            doc.save(out)
        }
    }

    /** Only works when the caller supplies the correct password – nothing is bypassed. */
    fun removeSecurity(src: File, out: File, password: String) {
        open(src, password).use { doc -> doc.setAllSecurityToBeRemoved(true); doc.save(out) }
    }

    // ---------------------------------------------------------------- watermark
    fun watermark(src: File, out: File, o: WmOpts) {
        val font = PDType1Font.HELVETICA_BOLD
        val tw = try { font.getStringWidth(o.text) / 1000f * o.size }
                 catch (e: Exception) { throw PdfError("The watermark text contains characters the built-in PDF font can't display (Latin text only).") }
        open(src).use { doc ->
            for (page in doc.pages) {
                val g = PageGeom(page)
                val fy = when (o.pos) { 1 -> 0.08f; 2 -> 0.92f; else -> 0.5f }
                val (cx, cy) = g.pt(0.5f, fy)
                val th = Math.toRadians(o.rotation.toDouble())
                val c = Math.cos(th).toFloat(); val s = Math.sin(th).toFloat()
                // text direction d and normal n in user space (rotated by the watermark angle)
                val dx = g.rx * c + g.ux * s; val dy = g.ry * c + g.uy * s
                val nx = -g.rx * s + g.ux * c; val ny = -g.ry * s + g.uy * c
                val ox = cx - dx * tw / 2 - nx * o.size * 0.35f
                val oy = cy - dy * tw / 2 - ny * o.size * 0.35f
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.setGraphicsStateParameters(PDExtendedGraphicsState().apply {
                        setNonStrokingAlphaConstant(o.opacity); setStrokingAlphaConstant(o.opacity) })
                    cs.beginText()
                    cs.setFont(font, o.size)
                    cs.setNonStrokingColor(Color.red(o.rgb), Color.green(o.rgb), Color.blue(o.rgb))
                    cs.setTextMatrix(Matrix(dx, dy, nx, ny, ox, oy))
                    cs.showText(o.text)
                    cs.endText()
                }
            }
            doc.save(out)
        }
    }

    // ---------------------------------------------------------------- images
    fun decodeImage(ctx: Context, uri: Uri, maxSide: Int, rotate: Int = 0): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri) // ImageDecoder also applies EXIF orientation
        val raw = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val m = maxOf(info.size.width, info.size.height)
            if (m > maxSide) {
                val f = maxSide.toFloat() / m
                dec.setTargetSize((info.size.width * f).toInt().coerceAtLeast(1), (info.size.height * f).toInt().coerceAtLeast(1))
            }
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
        val mat = android.graphics.Matrix().apply { postRotate(rotate.toFloat()) }
        val rotated = if (rotate % 360 != 0) Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, mat, true) else raw
        // flatten transparency onto white (PDF pages are JPEG-encoded here)
        val flat = Bitmap.createBitmap(rotated.width, rotated.height, Bitmap.Config.ARGB_8888)
        Canvas(flat).apply { drawColor(Color.WHITE); drawBitmap(rotated, 0f, 0f, null) }
        return flat
    }

    fun imagesToPdf(ctx: Context, imgs: List<Pair<Uri, Int>>, out: File, a4: Boolean, progress: (Float) -> Unit) {
        PDDocument().use { doc ->
            imgs.forEachIndexed { i, (uri, rot) ->
                val bmp = try { decodeImage(ctx, uri, 2400, rot) } catch (e: Exception) { throw PdfError("Couldn't read image ${i + 1}.") }
                val pd = JPEGFactory.createFromImage(doc, bmp, 0.9f)
                val iw = bmp.width.toFloat(); val ih = bmp.height.toFloat()
                val page: PDPage; val x: Float; val y: Float; val w: Float; val h: Float
                if (a4) {
                    val pr = if (iw > ih) PDRectangle(PDRectangle.A4.height, PDRectangle.A4.width) else PDRectangle.A4
                    page = PDPage(pr)
                    val s = minOf(pr.width / iw, pr.height / ih)
                    w = iw * s; h = ih * s; x = (pr.width - w) / 2; y = (pr.height - h) / 2
                } else {
                    val s = 842f / maxOf(iw, ih)
                    w = iw * s; h = ih * s; x = 0f; y = 0f
                    page = PDPage(PDRectangle(w, h))
                }
                doc.addPage(page)
                PDPageContentStream(doc, page).use { it.drawImage(pd, x, y, w, h) }
                bmp.recycle()
                progress((i + 1f) / imgs.size)
            }
            doc.save(out)
        }
    }

    fun pdfToImages(ctx: Context, src: File, tree: Uri, base: String, png: Boolean, progress: (Float) -> Unit): Int {
        val dir = DocumentFile.fromTreeUri(ctx, tree) ?: throw PdfError("Can't access the chosen folder.")
        val ps = PdfSource(src)
        try {
            for (i in 0 until ps.pageCount) {
                val (w, _) = ps.size(i)
                val bmp = ps.render(i, (w * 2f).toInt().coerceIn(600, 3000))
                val df = dir.createFile(if (png) "image/png" else "image/jpeg", "${base}_${i + 1}")
                    ?: throw PdfError("Couldn't create files in that folder.")
                val o = ctx.contentResolver.openOutputStream(df.uri) ?: throw PdfError("Couldn't write to that folder.")
                o.use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it) }
                bmp.recycle()
                progress((i + 1f) / ps.pageCount)
            }
            return ps.pageCount
        } finally { ps.close() }
    }

    // ---------------------------------------------------------------- text
    fun extractText(src: File, out: File) {
        open(src).use { doc -> OutputStreamWriter(out.outputStream(), Charsets.UTF_8).use { PDFTextStripper().writeText(doc, it) } }
        out.bufferedReader().use { r ->
            var c = r.read()
            while (c != -1) { if (!Character.isWhitespace(c)) return; c = r.read() }
        }
        throw PdfError("No selectable text found. This looks like a scanned/image-only PDF (OCR isn't included in this build).")
    }

    fun search(file: File, query: String, cancelled: () -> Boolean, onPage: (Int, Int) -> Unit, onHit: (Hit) -> Unit) {
        val q = query.lowercase()
        open(file).use { doc ->
            val st = PDFTextStripper()
            val n = doc.numberOfPages
            for (i in 1..n) {
                if (cancelled()) return
                onPage(i, n)
                st.startPage = i; st.endPage = i
                val text = st.getText(doc).replace('\n', ' ')
                val low = text.lowercase()
                var at = low.indexOf(q)
                while (at >= 0) {
                    onHit(Hit(i - 1, "…" + text.substring(maxOf(0, at - 30), minOf(text.length, at + q.length + 40)).trim() + "…"))
                    at = low.indexOf(q, at + q.length)
                }
            }
        }
    }

    // ---------------------------------------------------------------- overlays (annotate / sign / fill / redact)
    private fun rgbOf(c: Int) = Triple(Color.red(c), Color.green(c), Color.blue(c))

    fun applyOverlays(src: File, out: File, items: List<Item>) {
        val redactions = items.filterIsInstance<Item.Rect>().filter { it.kind == 2 }
        val visible = items.filterNot { it is Item.Rect && it.kind == 2 }
        val stage = if (redactions.isEmpty()) out else File(out.parentFile, "stage.pdf")
        open(src).use { doc ->
            val imgCache = HashMap<Bitmap, PDImageXObject>()
            for ((pi, list) in visible.groupBy { it.page }) {
                val page = doc.getPage(pi)
                val g = PageGeom(page)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    list.forEach { drawItem(doc, cs, g, it, imgCache) }
                }
            }
            doc.save(stage)
        }
        if (redactions.isNotEmpty()) { redact(stage, out, redactions); stage.delete() }
    }

    private fun alpha(cs: PDPageContentStream, a: Float) =
        cs.setGraphicsStateParameters(PDExtendedGraphicsState().apply { setNonStrokingAlphaConstant(a); setStrokingAlphaConstant(a) })

    private fun drawItem(doc: PDDocument, cs: PDPageContentStream, g: PageGeom, it: Item, cache: HashMap<Bitmap, PDImageXObject>) {
        when (it) {
            is Item.Text -> {
                val (r, gr, b) = rgbOf(it.rgb)
                val (ox, oy) = g.pt(it.fx, it.fy)
                cs.beginText()
                cs.setFont(Fonts.pdf(it.family, it.bold), it.size)
                cs.setNonStrokingColor(r, gr, b)
                cs.setTextMatrix(Matrix(g.rx, g.ry, g.ux, g.uy, ox, oy))
                cs.showText(it.text)
                cs.endText()
            }
            is Item.Img -> {
                val pd = cache.getOrPut(it.bmp) { LosslessFactory.createFromImage(doc, it.bmp) }
                val wPts = it.fw * g.dispW
                val hPts = wPts * it.bmp.height / it.bmp.width
                val (px, py) = g.pt(it.fx, it.fy + hPts / g.dispH) // visual bottom-left corner
                // unit square -> right vector * width, up vector * height
                cs.drawImage(pd, Matrix(g.rx * wPts, g.ry * wPts, g.ux * hPts, g.uy * hPts, px, py))
            }
            is Item.Ink -> {
                if (it.pts.size < 2) return
                val (r, gr, b) = rgbOf(it.rgb)
                cs.saveGraphicsState()
                alpha(cs, it.alpha)
                cs.setStrokingColor(r, gr, b)
                cs.setLineWidth(it.width)
                cs.setLineCapStyle(1); cs.setLineJoinStyle(1)
                it.pts.forEachIndexed { i, p -> val (x, y) = g.pt(p.first, p.second); if (i == 0) cs.moveTo(x, y) else cs.lineTo(x, y) }
                cs.stroke()
                cs.restoreGraphicsState()
            }
            is Item.Rect -> {
                val (r, gr, b) = rgbOf(it.rgb)
                val a = g.pt(it.fx, it.fy); val bb = g.pt(it.fx + it.fw, it.fy)
                val c = g.pt(it.fx + it.fw, it.fy + it.fh); val d = g.pt(it.fx, it.fy + it.fh)
                cs.saveGraphicsState()
                cs.moveTo(a.first, a.second); cs.lineTo(bb.first, bb.second); cs.lineTo(c.first, c.second); cs.lineTo(d.first, d.second); cs.closePath()
                if (it.kind == 0) { alpha(cs, 0.35f); cs.setNonStrokingColor(r, gr, b); cs.fill() }
                else { cs.setStrokingColor(r, gr, b); cs.setLineWidth(2f); cs.stroke() }
                cs.restoreGraphicsState()
            }
        }
    }

    /**
     * True redaction: every page that has a redaction box is rendered to a bitmap, the boxes are
     * painted solid black into the pixels, and the page is REPLACED by that image. The original text
     * and vector content of those pages no longer exists in the file (they also stop being selectable).
     * Document-level metadata / outlines are not scrubbed.
     */
    private fun redact(stage: File, out: File, rects: List<Item.Rect>) {
        val ps = PdfSource(stage)
        try {
            open(stage).use { doc ->
                for ((pi, rs) in rects.groupBy { it.page }) {
                    val old = doc.getPage(pi)
                    val g = PageGeom(old)
                    val bmp = ps.render(pi, 1650)
                    val cv = Canvas(bmp)
                    val paint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
                    rs.forEach { cv.drawRect(it.fx * bmp.width, it.fy * bmp.height, (it.fx + it.fw) * bmp.width, (it.fy + it.fh) * bmp.height, paint) }
                    val np = PDPage(PDRectangle(g.dispW, g.dispH))
                    doc.pages.insertBefore(np, old)
                    doc.pages.remove(old)
                    PDPageContentStream(doc, np).use { it.drawImage(JPEGFactory.createFromImage(doc, bmp, 0.92f), 0f, 0f, g.dispW, g.dispH) }
                    bmp.recycle()
                }
                doc.save(out)
            }
        } finally { ps.close() }
    }
}
