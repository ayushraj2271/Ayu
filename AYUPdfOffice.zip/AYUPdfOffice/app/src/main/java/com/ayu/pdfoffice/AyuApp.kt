package com.ayu.pdfoffice

import android.app.Application
import com.ayu.pdfoffice.data.Store
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class AyuApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(applicationContext) // loads PdfBox fonts/glyph lists from assets
        Store.init(this)
    }
}
