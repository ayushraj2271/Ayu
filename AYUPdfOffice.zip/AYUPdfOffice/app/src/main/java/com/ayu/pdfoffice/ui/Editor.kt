@file:OptIn(ExperimentalMaterial3Api::class)
package com.ayu.pdfoffice.ui

import android.graphics.Bitmap
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.ayu.pdfoffice.data.FileUtil
import com.ayu.pdfoffice.data.Pending
import com.ayu.pdfoffice.pdf.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Tl(val label: String, val icon: ImageVector) {
    Select("Select", Icons.Default.TouchApp), Text("Text", Icons.Default.TextFields), Pen("Pen", Icons.Default.Brush),
    Highlight("Highlight", Icons.Default.Highlight), Rect("Rectangle", Icons.Default.CropSquare), Sign("Signature", Icons.Default.Gesture),
    Check("Check", Icons.Default.Check), Cross("Cross", Icons.Default.Close), Date("Date", Icons.Default.DateRange),
    Image("Image", Icons.Default.Image), Redact("Redact", Icons.Default.VisibilityOff)
}

private val Palette = listOf(0xFF111111, 0xFF1A237E, 0xFFC62828, 0xFF2E7D32, 0xFFEF6C00).map { it.toInt() }
private val HlPalette = listOf(0xFFFFEB3B, 0xFF66BB6A, 0xFFF48FB1, 0xFF64B5F6).map { it.toInt() }

private fun stampBitmap(check: Boolean, rgb: Int): Bitmap {
    val b = Bitmap.createBitmap(120, 120, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(b)
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 14f; color = rgb; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    val path = android.graphics.Path()
    if (check) { path.moveTo(15f, 65f); path.lineTo(45f, 95f); path.lineTo(105f, 25f) }
    else { path.moveTo(20f, 20f); path.lineTo(100f, 100f); path.moveTo(100f, 20f); path.lineTo(20f, 100f) }
    c.drawPath(path, p)
    return b
}

private fun drawItem(c: android.graphics.Canvas, item: Item, w: Float, h: Float, scale: Float, p: Paint) {
    p.reset(); p.isAntiAlias = true
    when (item) {
        is Item.Text -> { p.color = item.rgb; p.textSize = item.size * scale; p.typeface = Fonts.typeface(item.family, item.bold); c.drawText(item.text, item.fx * w, item.fy * h, p) }
        is Item.Img -> {
            val bw = item.fw * w; val bh = bw * item.bmp.height / item.bmp.width
            p.isFilterBitmap = true
            c.drawBitmap(item.bmp, null, RectF(item.fx * w, item.fy * h, item.fx * w + bw, item.fy * h + bh), p)
        }
        is Item.Ink -> {
            p.style = Paint.Style.STROKE; p.color = item.rgb; p.alpha = (item.alpha * 255).toInt()
            p.strokeWidth = item.width * scale; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
            val path = android.graphics.Path()
            item.pts.forEachIndexed { i, q -> if (i == 0) path.moveTo(q.first * w, q.second * h) else path.lineTo(q.first * w, q.second * h) }
            c.drawPath(path, p)
        }
        is Item.Rect -> {
            val r = RectF(item.fx * w, item.fy * h, (item.fx + item.fw) * w, (item.fy + item.fh) * h)
            when (item.kind) {
                0 -> { p.color = item.rgb; p.alpha = 90; p.style = Paint.Style.FILL; c.drawRect(r, p) }
                1 -> { p.color = item.rgb; p.style = Paint.Style.STROKE; p.strokeWidth = 2f * scale; c.drawRect(r, p) }
                else -> { p.color = android.graphics.Color.BLACK; p.alpha = 150; p.style = Paint.Style.FILL; c.drawRect(r, p) } // preview only
            }
        }
    }
}

@Composable
fun EditorScreen(nav: NavHostController, mode: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val t = rememberTool()
    val hist = remember { History<List<Item>>(emptyList()) }
    val holder = remember { arrayOfNulls<PdfSource>(1) }
    var src by remember { mutableStateOf<PdfSource?>(null) }
    var sizes by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }
    var page by remember { mutableIntStateOf(0) }
    var tool by remember { mutableStateOf(when (mode) { "sign" -> Tl.Sign; "fill" -> Tl.Text; "redact" -> Tl.Redact; else -> Tl.Pen }) }
    var sel by remember { mutableIntStateOf(-1) }
    var live by remember { mutableStateOf<List<Item>?>(null) }
    var draftRect by remember { mutableStateOf<Item.Rect?>(null) }
    val inkPts = remember { mutableStateListOf<Pair<Float, Float>>() }
    var color by remember { mutableIntStateOf(Palette[1]) }
    var hlColor by remember { mutableIntStateOf(HlPalette[0]) }
    var family by remember { mutableIntStateOf(0) }
    var bold by remember { mutableStateOf(false) }
    var fontSize by remember { mutableFloatStateOf(14f) }
    var penW by remember { mutableFloatStateOf(3f) }
    var penA by remember { mutableFloatStateOf(1f) }
    var sig by remember { mutableStateOf(Sigs.load(ctx)) }
    var askText by remember { mutableStateOf<Pair<Float, Float>?>(null) }
    var textErr by remember { mutableStateOf<String?>(null) }
    var sigDialog by remember { mutableStateOf(false) }
    var confirmRedact by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var imgPos by remember { mutableStateOf(0f to 0f) }
    val flow = rememberSaveFlow(onError = { t.error = it })
    val items = live ?: hist.current

    fun open(uri: android.net.Uri) = t.load(uri) { d ->
        t.exec("Preparing pages…", { val s = PdfSource(d.file); s to List(s.pageCount) { s.size(it) } }) { (s, z) ->
            holder[0] = s; src = s; sizes = z
            if (tool == Tl.Sign && sig == null) sigDialog = true
        }
    }
    val pick = rememberPdfPicker { open(it) }
    LaunchedEffect(Unit) { Pending.take()?.let { open(it) } }
    DisposableEffect(Unit) { onDispose { holder[0]?.close() } }
    BackHandler(hist.current.isNotEmpty()) { confirmExit = true }

    fun disp() = sizes.getOrNull(page)?.let { it.first.toFloat() to it.second.toFloat() } ?: (595f to 842f)
    fun add(item: Item) { hist.push(hist.current + item); sel = hist.current.lastIndex; tool = Tl.Select }
    fun centered(bmp: Bitmap, fw: Float, fx: Float, fy: Float): Pair<Float, Float> {
        val (dw, dh) = disp(); val hf = fw * dw * bmp.height / bmp.width / dh
        return (fx - fw / 2) to (fy - hf / 2)
    }
    fun hit(fx: Float, fy: Float): Int {
        val (dw, dh) = disp()
        for (i in items.indices.reversed()) {
            val it = items[i]
            if (it.page == page && it.boundsFrac(dw, dh).contains(fx, fy)) return i
        }
        return -1
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) { PdfOps.decodeImage(ctx, u, 1200) }
                val (x, y) = centered(bmp, 0.3f, imgPos.first, imgPos.second)
                add(Item.Img(page, bmp, x, y, 0.3f))
            } catch (e: Throwable) { t.error = "Couldn't read that image." }
        }
    }
    fun onTap(fx: Float, fy: Float) {
        when (tool) {
            Tl.Select -> sel = hit(fx, fy)
            Tl.Text -> { textErr = null; askText = fx to fy }
            Tl.Date -> add(Item.Text(page, SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()), fx, fy, fontSize, color, family, bold))
            Tl.Check, Tl.Cross -> { val b = stampBitmap(tool == Tl.Check, color); val (x, y) = centered(b, 0.04f, fx, fy); add(Item.Img(page, b, x, y, 0.04f)) }
            Tl.Sign -> sig?.let { val (x, y) = centered(it, 0.25f, fx, fy); add(Item.Img(page, it, x, y, 0.25f)) } ?: run { sigDialog = true }
            Tl.Image -> { imgPos = fx to fy; imagePicker.launch("image/*") }
            else -> {}
        }
    }
    fun export() {
        val d = t.doc ?: return
        val list = hist.current
        t.exec("Saving PDF…", { val out = FileUtil.newOut(ctx, "${d.base}_edited.pdf"); PdfOps.applyOverlays(d.file, out, list); out }) { flow.start(it) }
    }
    fun resize(f: Float) {
        if (sel !in items.indices) return
        val it = items[sel]
        val n = when (it) { is Item.Text -> it.copy(size = (it.size * f).coerceIn(6f, 120f)); is Item.Img -> it.copy(fw = (it.fw * f).coerceIn(0.02f, 1f)); else -> it }
        hist.push(items.toMutableList().also { l -> l[sel] = n })
    }

    ToolScaffold(t.doc?.name ?: "Editor", onBack = { if (hist.current.isNotEmpty()) confirmExit = true else nav.popBackStack() },
        actions = {
            IconButton({ hist.undo(); sel = -1 }, enabled = hist.canUndo) { Icon(Icons.Default.Undo, "Undo") }
            IconButton({ hist.redo(); sel = -1 }, enabled = hist.canRedo) { Icon(Icons.Default.Redo, "Redo") }
            IconButton({ if (items.any { it is Item.Rect && it.kind == 2 }) confirmRedact = true else export() }, enabled = items.isNotEmpty()) { Icon(Icons.Default.Save, "Save") }
        },
        bottomBar = {
            if (src != null) Surface(tonalElevation = 3.dp) {
                Column(Modifier.navigationBarsPadding()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        IconButton({ page = (page - 1).coerceAtLeast(0); sel = -1 }, enabled = page > 0) { Icon(Icons.Default.KeyboardArrowLeft, "Previous page") }
                        Text("Page ${page + 1} of ${sizes.size}")
                        IconButton({ page = (page + 1).coerceAtMost(sizes.size - 1); sel = -1 }, enabled = page < sizes.size - 1) { Icon(Icons.Default.KeyboardArrowRight, "Next page") }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
                        Tl.values().forEach { tt ->
                            FilterChip(tool == tt, { tool = tt; if (tt == Tl.Sign && sig == null) sigDialog = true }, { Text(tt.label) },
                                Modifier.padding(end = 6.dp), leadingIcon = { Icon(tt.icon, null, Modifier.size(18.dp)) })
                        }
                    }
                    // contextual toolbar
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        when (tool) {
                            Tl.Text, Tl.Date -> {
                                TextButton({ family = (family + 1) % 3 }) { Text(Fonts.names[family]) }
                                FilterChip(bold, { bold = !bold }, { Text("Bold") })
                                IconButton({ fontSize = (fontSize - 2).coerceAtLeast(6f) }) { Icon(Icons.Default.Remove, "Smaller text") }
                                Text("${fontSize.toInt()} pt")
                                IconButton({ fontSize = (fontSize + 2).coerceAtMost(96f) }) { Icon(Icons.Default.Add, "Larger text") }
                                ColorDots(Palette, color) { color = it }
                            }
                            Tl.Pen -> {
                                ColorDots(Palette, color) { color = it }
                                Text("Thickness"); Slider(penW, { penW = it }, Modifier.width(110.dp), valueRange = 1f..16f)
                                Text("Opacity"); Slider(penA, { penA = it }, Modifier.width(110.dp), valueRange = 0.2f..1f)
                            }
                            Tl.Highlight -> ColorDots(HlPalette, hlColor) { hlColor = it }
                            Tl.Rect, Tl.Check, Tl.Cross -> ColorDots(Palette, color) { color = it }
                            Tl.Sign -> {
                                sig?.let { Image(it.asImageBitmap(), "Current signature", Modifier.height(36.dp).background(Color.White)) }
                                TextButton({ sigDialog = true }) { Text(if (sig == null) "Create signature" else "Change signature") }
                                Text("Tap the page to place it", style = MaterialTheme.typography.bodySmall)
                            }
                            Tl.Redact -> Text("Drag over content to redact. Applied when you save.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
                            Tl.Image -> Text("Tap the page, then choose an image", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
                            Tl.Select -> if (sel in items.indices) {
                                IconButton({ hist.push(items.filterIndexed { i, _ -> i != sel }); sel = -1 }) { Icon(Icons.Default.Delete, "Delete selected") }
                                IconButton({ resize(0.87f) }) { Icon(Icons.Default.Remove, "Smaller") }
                                IconButton({ resize(1.15f) }) { Icon(Icons.Default.Add, "Larger") }
                                Text("Drag on the page to move", style = MaterialTheme.typography.bodySmall)
                            } else Text("Tap an item to select it", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp))
                        }
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            val s = src
            if (s == null) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Text("Choose a PDF to edit. Your original file is never changed – changes are saved as a new copy.")
                    Spacer(Modifier.height(12.dp)); Button(pick) { Text("Open PDF") }
                }
            } else BoxWithConstraints(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
                val (pw, ph) = sizes[page]
                val aspect = pw.toFloat() / ph
                val bmp by produceState<Bitmap?>(null, s, page) { value = try { BitmapCache.get(s, page, 1400) } catch (e: Exception) { null } }
                val paint = remember { Paint() }
                Box(Modifier.aspectRatio(aspect, matchHeightConstraintsFirst = maxWidth / maxHeight > aspect).background(Color.White)) {
                    bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds) }
                    Canvas(Modifier.fillMaxSize()
                        .pointerInput(tool, page) { detectTapGestures { o -> onTap(o.x / size.width, o.y / size.height) } }
                        .pointerInput(tool, page) {
                            var anchor = 0f to 0f
                            fun rectOf(a: Pair<Float, Float>, b: Pair<Float, Float>) = Item.Rect(page,
                                minOf(a.first, b.first), minOf(a.second, b.second), Math.abs(a.first - b.first), Math.abs(a.second - b.second),
                                when (tool) { Tl.Highlight -> 0; Tl.Redact -> 2; else -> 1 }, if (tool == Tl.Highlight) hlColor else color)
                            detectDragGestures(
                                onDragStart = { o ->
                                    val fx = o.x / size.width; val fy = o.y / size.height
                                    when (tool) {
                                        Tl.Select -> { sel = hit(fx, fy); if (sel >= 0) live = hist.current }
                                        Tl.Pen -> { inkPts.clear(); inkPts.add(fx to fy) }
                                        Tl.Highlight, Tl.Rect, Tl.Redact -> { anchor = fx to fy; draftRect = rectOf(anchor, anchor) }
                                        else -> {}
                                    }
                                },
                                onDrag = { change, drag ->
                                    change.consume()
                                    val fx = (change.position.x / size.width).coerceIn(0f, 1f); val fy = (change.position.y / size.height).coerceIn(0f, 1f)
                                    when (tool) {
                                        Tl.Select -> live?.let { l -> if (sel in l.indices) live = l.toMutableList().also { m -> m[sel] = m[sel].moved(drag.x / size.width, drag.y / size.height) } }
                                        Tl.Pen -> inkPts.add(fx to fy)
                                        Tl.Highlight, Tl.Rect, Tl.Redact -> draftRect = rectOf(anchor, fx to fy)
                                        else -> {}
                                    }
                                },
                                onDragEnd = {
                                    when (tool) {
                                        Tl.Select -> live?.let { if (it !== hist.current) hist.push(it) }
                                        Tl.Pen -> { if (inkPts.size >= 2) hist.push(hist.current + Item.Ink(page, inkPts.toList(), color, penW, penA)); inkPts.clear() }
                                        Tl.Highlight, Tl.Rect, Tl.Redact -> { draftRect?.let { if (it.fw > 0.005f && it.fh > 0.005f) hist.push(hist.current + it) }; draftRect = null }
                                        else -> {}
                                    }
                                    live = null
                                },
                                onDragCancel = { live = null; draftRect = null; inkPts.clear() }
                            )
                        }
                    ) {
                        val w = size.width; val h = size.height; val scale = w / pw
                        drawIntoCanvas { c ->
                            val nc = c.nativeCanvas
                            items.forEachIndexed { i, it ->
                                if (it.page != page) return@forEachIndexed
                                drawItem(nc, it, w, h, scale, paint)
                                if (i == sel) {
                                    val b = it.boundsFrac(pw.toFloat(), ph.toFloat())
                                    paint.reset(); paint.style = Paint.Style.STROKE; paint.color = 0xFF1565C0.toInt(); paint.strokeWidth = 3f
                                    paint.pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
                                    nc.drawRect(b.left * w, b.top * h, b.right * w, b.bottom * h, paint)
                                }
                            }
                            draftRect?.let { drawItem(nc, it, w, h, scale, paint) }
                            if (inkPts.size >= 2) drawItem(nc, Item.Ink(page, inkPts.toList(), color, penW, penA), w, h, scale, paint)
                        }
                    }
                }
            }
        }
    }

    askText?.let { (fx, fy) ->
        var text by remember { mutableStateOf("") }
        AlertDialog({ askText = null }, title = { Text("Add text") },
            text = { Column { OutlinedTextField(text, { text = it; textErr = null }, singleLine = true); textErr?.let { Text(it, color = MaterialTheme.colorScheme.error) } } },
            confirmButton = {
                TextButton({
                    if (text.isNotBlank()) {
                        if (!Fonts.encodable(family, bold, text)) textErr = "Built-in PDF fonts support Latin characters only."
                        else { askText = null; add(Item.Text(page, text, fx, fy, fontSize, color, family, bold)) }
                    }
                }) { Text("Add") }
            }, dismissButton = { TextButton({ askText = null }) { Text("Cancel") } })
    }
    if (sigDialog) SignatureDialog(onDone = { b -> sig = b; Sigs.save(ctx, b); sigDialog = false; tool = Tl.Sign }, onDismiss = { sigDialog = false })
    if (confirmRedact) AlertDialog({ confirmRedact = false }, title = { Text("Apply redaction?") },
        text = { Text("Redaction permanently removes the selected content from the exported PDF. Pages with redactions are converted to images (their text is no longer selectable). This action cannot be undone after export. Continue?") },
        confirmButton = { TextButton({ confirmRedact = false; export() }) { Text("Continue") } },
        dismissButton = { TextButton({ confirmRedact = false }) { Text("Cancel") } })
    if (confirmExit) AlertDialog({ confirmExit = false }, title = { Text("Discard changes?") }, text = { Text("Your edits haven't been saved.") },
        confirmButton = { TextButton({ confirmExit = false; nav.popBackStack() }) { Text("Discard") } },
        dismissButton = { TextButton({ confirmExit = false }) { Text("Keep editing") } })
    ToolHost(t)
    SavedDialog(flow) { nav.openPdf(it) }
}

/** Object for the user's reusable signature image (private app storage). */
object Sigs {
    fun load(ctx: android.content.Context): Bitmap? =
        File(ctx.filesDir, "signature.png").takeIf { it.exists() }?.let { android.graphics.BitmapFactory.decodeFile(it.path) }
    fun save(ctx: android.content.Context, b: Bitmap) {
        runCatching { File(ctx.filesDir, "signature.png").outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }
    fun fromStrokes(strokes: List<List<Offset>>): Bitmap? {
        val pts = strokes.flatten()
        if (pts.size < 2) return null
        val pad = 12f
        val minX = pts.minOf { it.x } - pad; val minY = pts.minOf { it.y } - pad
        val b = Bitmap.createBitmap((pts.maxOf { it.x } + pad - minX).toInt().coerceAtLeast(8), (pts.maxOf { it.y } + pad - minY).toInt().coerceAtLeast(8), Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f; color = 0xFF0D1B6B.toInt(); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        strokes.forEach { s ->
            val path = android.graphics.Path()
            s.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x - minX, o.y - minY) else path.lineTo(o.x - minX, o.y - minY) }
            c.drawPath(path, p)
        }
        return b
    }
    fun typed(text: String): Bitmap {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 120f; color = 0xFF0D1B6B.toInt(); typeface = Typeface.create(Typeface.create("cursive", Typeface.NORMAL), Typeface.ITALIC) }
        val b = Bitmap.createBitmap(p.measureText(text).toInt() + 40, 180, Bitmap.Config.ARGB_8888)
        android.graphics.Canvas(b).drawText(text, 20f, 125f, p)
        return b
    }
}

@Composable
fun SignatureDialog(onDone: (Bitmap) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var typed by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch { runCatching { withContext(Dispatchers.IO) { PdfOps.decodeImage(ctx, u, 800) } }.onSuccess(onDone) }
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Signature") },
        text = {
            Column {
                Text("This is a visual (image) signature. It is not a cryptographic digital-certificate signature.", style = MaterialTheme.typography.bodySmall)
                TabRow(tab) { listOf("Draw", "Type", "Import").forEachIndexed { i, s -> Tab(tab == i, { tab = i }, text = { Text(s) }) } }
                Spacer(Modifier.height(8.dp))
                when (tab) {
                    0 -> Canvas(Modifier.fillMaxWidth().height(160.dp).background(Color.White)
                        .pointerInput(Unit) {
                            detectDragGestures(onDragStart = { cur = listOf(it) },
                                onDrag = { c, _ -> c.consume(); cur = cur + c.position },
                                onDragEnd = { strokes.add(cur); cur = emptyList() })
                        }) {
                        (strokes + listOf(cur)).forEach { s ->
                            if (s.size > 1) drawPath(Path().apply { moveTo(s[0].x, s[0].y); s.drop(1).forEach { lineTo(it.x, it.y) } },
                                Color(0xFF0D1B6B), style = Stroke(6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                    }
                    1 -> OutlinedTextField(typed, { typed = it }, singleLine = true, label = { Text("Your name") })
                    else -> Button({ pick.launch("image/*") }) { Text("Choose signature image") }
                }
            }
        },
        confirmButton = {
            if (tab < 2) TextButton({
                val b = if (tab == 0) Sigs.fromStrokes(strokes.toList()) else typed.takeIf { it.isNotBlank() }?.let { Sigs.typed(it) }
                b?.let(onDone)
            }) { Text("Use") }
        },
        dismissButton = {
            Row {
                if (tab == 0) TextButton({ strokes.clear() }) { Text("Clear") }
                TextButton(onDismiss) { Text("Cancel") }
            }
        })
}
