package com.ayu.pdfoffice.pdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Page rendering on top of android.graphics.pdf.PdfRenderer. The renderer only allows one open page
 * at a time, so every call is synchronized. Pages are rendered one by one on demand – the whole
 * document is never decoded into memory. Throws SecurityException for password-protected files.
 */
class PdfSource(val file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = try { PdfRenderer(pfd) } catch (e: Throwable) { pfd.close(); throw e }
    val pageCount: Int = renderer.pageCount

    /** Page size in PDF points, with /Rotate already applied. */
    fun size(i: Int): Pair<Int, Int> = synchronized(this) {
        val p = renderer.openPage(i)
        try { p.width to p.height } finally { p.close() }
    }

    fun render(i: Int, widthPx: Int, rotation: Int = 0): Bitmap = synchronized(this) {
        val p = renderer.openPage(i)
        try {
            val w = widthPx.coerceAtLeast(16)
            val h = (w * p.height.toFloat() / p.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            if (rotation % 360 != 0) {
                val m = android.graphics.Matrix().apply { postRotate(rotation.toFloat()) }
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            } else bmp
        } finally { p.close() }
    }

    fun close() = synchronized(this) {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
    }
}

/** Memory-bounded bitmap cache (1/6 of the heap, max 96 MB). Old bitmaps are simply dropped for the GC. */
object BitmapCache {
    private val lru = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 6).toInt().coerceAtMost(96 * 1024 * 1024)
    ) { override fun sizeOf(key: String, value: Bitmap) = value.byteCount }

    suspend fun get(src: PdfSource, i: Int, widthPx: Int, rotation: Int = 0): Bitmap {
        val key = "${src.file.path}|${src.file.lastModified()}|$i|$widthPx|$rotation"
        lru.get(key)?.let { return it }
        val b = withContext(Dispatchers.IO) { src.render(i, widthPx, rotation) }
        lru.put(key, b)
        return b
    }
}
