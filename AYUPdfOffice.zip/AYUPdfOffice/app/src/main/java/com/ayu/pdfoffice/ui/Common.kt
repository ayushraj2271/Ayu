@file:OptIn(ExperimentalMaterial3Api::class)
package com.ayu.pdfoffice.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavHostController
import com.ayu.pdfoffice.data.FileUtil
import com.ayu.pdfoffice.data.Store
import com.ayu.pdfoffice.pdf.PdfError
import com.ayu.pdfoffice.pdf.PdfOps
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import java.io.File

fun Context.activity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

fun NavHostController.openPdf(uri: Uri) = navigate("viewer/${Uri.encode(uri.toString())}")

@Composable
fun ToolScaffold(
    title: String, onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = actions
            )
        },
        bottomBar = bottomBar, content = content
    )
}

/** A PDF copied to the private cache (the original is never touched by tools). */
class PdfDoc(val uri: Uri, val name: String, val file: File, val pages: Int, val locked: Boolean = false) {
    val base get() = name.removeSuffix(".pdf").removeSuffix(".PDF")
}

suspend fun loadPdf(ctx: Context, uri: Uri, allowLocked: Boolean = false): PdfDoc = withContext(Dispatchers.IO) {
    val m = FileUtil.meta(ctx, uri)
    val f = FileUtil.copyToCache(ctx, uri, m.name)
    try { PdfDoc(uri, m.name, f, PdfOps.pageCount(f)) }
    catch (e: InvalidPasswordException) {
        if (!allowLocked) throw PdfError("This PDF is password-protected. Use Protect PDF → Remove security (with the password) first.")
        PdfDoc(uri, m.name, f, 0, true)
    }
}

/** Shared state for a tool screen: busy indicator, error dialog and the selected PDF. */
class Tool(val ctx: Context, val scope: CoroutineScope) {
    var busy by mutableStateOf<String?>(null)
    var progress by mutableFloatStateOf(-1f)
    var error by mutableStateOf<String?>(null)
    var doc by mutableStateOf<PdfDoc?>(null)

    fun <T> exec(label: String, work: () -> T, done: (T) -> Unit = {}) {
        scope.launch {
            busy = label; progress = -1f
            try { done(withContext(Dispatchers.IO) { work() }) }
            catch (e: CancellationException) { throw e }
            catch (e: Throwable) { error = PdfOps.friendly(e) }
            finally { busy = null }
        }
    }

    fun load(uri: Uri, allowLocked: Boolean = false, then: (PdfDoc) -> Unit = {}) {
        scope.launch {
            busy = "Opening…"; progress = -1f
            try { val d = loadPdf(ctx, uri, allowLocked); doc = d; then(d) }
            catch (e: CancellationException) { throw e }
            catch (e: Throwable) { error = PdfOps.friendly(e) }
            finally { busy = null }
        }
    }
}

@Composable
fun rememberTool(): Tool {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    return remember { Tool(ctx, scope) }
}

@Composable
fun ToolHost(t: Tool) {
    t.busy?.let { label ->
        Dialog(onDismissRequest = {}) {
            Card {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (t.progress in 0f..1f) CircularProgressIndicator(progress = { t.progress }) else CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp)); Text(label)
                }
            }
        }
    }
    t.error?.let {
        AlertDialog(onDismissRequest = { t.error = null }, confirmButton = { TextButton({ t.error = null }) { Text("OK") } },
            title = { Text("Couldn't complete that") }, text = { Text(it) })
    }
}

/** "Save as…" through the system file picker; the result is copied only after the user picks a location. */
class SaveFlow(val mime: String) {
    var pending: File? = null
    var saved by mutableStateOf<Uri?>(null)
    var launch: (String) -> Unit = {}
    fun start(f: File) { pending = f; launch(f.name) }
}

@Composable
fun rememberSaveFlow(mime: String = "application/pdf", onError: (String) -> Unit): SaveFlow {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val flow = remember { SaveFlow(mime) }
    val l = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(mime)) { uri ->
        val f = flow.pending
        if (uri != null && f != null) scope.launch {
            try {
                val meta = withContext(Dispatchers.IO) { FileUtil.copyTo(ctx, f, uri); FileUtil.persist(ctx, uri); FileUtil.meta(ctx, uri) }
                if (mime == "application/pdf") Store.touch(uri.toString(), meta.name, f.length())
                flow.saved = uri
            } catch (e: Exception) { onError(PdfOps.friendly(e)) }
        }
    }
    flow.launch = { name -> l.launch(name) }
    return flow
}

@Composable
fun SavedDialog(flow: SaveFlow, onOpen: ((Uri) -> Unit)?) {
    val ctx = LocalContext.current
    flow.saved?.let { uri ->
        AlertDialog(
            onDismissRequest = { flow.saved = null },
            title = { Text(if (flow.mime == "application/pdf") "PDF saved successfully" else "File saved successfully") },
            confirmButton = {
                Row {
                    if (onOpen != null) TextButton({ flow.saved = null; onOpen(uri) }) { Text("Open") }
                    TextButton({ FileUtil.shareUri(ctx, uri, flow.mime) }) { Text("Share") }
                    TextButton({ flow.saved = null }) { Text("Done") }
                }
            }
        )
    }
}

@Composable
fun rememberPdfPicker(onPicked: (Uri) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val l = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { FileUtil.persist(ctx, u); onPicked(u) }
    }
    return { l.launch(arrayOf("application/pdf")) }
}

@Composable
fun SectionTitle(text: String) =
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))

@Composable
fun ColorDots(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        colors.forEach { c ->
            Box(Modifier.size(44.dp).padding(6.dp).clip(CircleShape).background(Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                .clickable { onPick(c) }.semantics { contentDescription = "Colour" })
        }
    }
}

@Composable
fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, s -> FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(s) }) }
    }
}

/** Shows the currently selected file with a "Change" button. */
@Composable
fun FileCard(doc: PdfDoc?, prompt: String, onPick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onPick)) {
        Row(Modifier.padding(16.dp).heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(doc?.name ?: prompt, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (doc != null) Text(if (doc.locked) "Password-protected" else "${doc.pages} pages · ${FileUtil.size(doc.file.length())}",
                    style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onPick) { Text(if (doc == null) "Choose PDF" else "Change") }
        }
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier =
    this.then(Modifier.horizontalScroll(rememberScrollState()))
