@file:OptIn(ExperimentalMaterial3Api::class)
package com.ayu.pdfoffice.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.ayu.pdfoffice.data.FileUtil
import com.ayu.pdfoffice.data.Pending
import com.ayu.pdfoffice.pdf.*
import java.io.File

/**
 * Page organizer. All edits are a plan (list of PageRef) with undo/redo; the PDF is only rebuilt on Save/Extract,
 * and always written as a NEW file. Reordering uses Move earlier / Move later (no drag-and-drop in this build).
 */
@Composable
fun OrganizerScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    val files = remember { mutableStateListOf<File>() }
    val sources = remember { mutableStateListOf<PdfSource>() }
    val hist = remember { History<List<PageRef>>(emptyList()) }
    var selected by remember { mutableStateOf(setOf<Int>()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val flow = rememberSaveFlow(onError = { t.error = it })
    val pages = hist.current

    fun openMain(uri: android.net.Uri) = t.load(uri) { d ->
        t.exec("Preparing pages…", { PdfSource(d.file) }) { s ->
            files.clear(); sources.clear(); files.add(d.file); sources.add(s)
            hist.push(List(s.pageCount) { PageRef(0, it) }); selected = emptySet()
        }
    }
    val pickMain = rememberPdfPicker { openMain(it) }
    val pickMore = rememberPdfPicker { uri ->
        t.load(uri) { d ->
            t.exec("Adding pages…", { PdfSource(d.file) }) { s ->
                val si = files.size; files.add(d.file); sources.add(s)
                hist.push(pages + List(s.pageCount) { PageRef(si, it) })
            }
        }
    }
    LaunchedEffect(Unit) { Pending.take()?.let { openMain(it) } }
    DisposableEffect(Unit) { onDispose { sources.forEach { it.close() } } }

    fun edit(f: (List<PageRef>) -> List<PageRef>) { hist.push(f(pages)); }
    val sel = selected.sorted()

    fun save(only: List<PageRef>, suffix: String) {
        val base = files.firstOrNull()?.nameWithoutExtension ?: "document"
        val fl = files.toList()
        t.exec("Saving PDF…", { val out = FileUtil.newOut(ctx, "${base}_$suffix.pdf"); PdfOps.build(fl, only, out); out }) { flow.start(it) }
    }

    ToolScaffold("Organize pages", { nav.popBackStack() }, actions = {
        IconButton({ hist.undo(); selected = emptySet() }, enabled = hist.canUndo) { Icon(Icons.Default.Undo, "Undo") }
        IconButton({ hist.redo(); selected = emptySet() }, enabled = hist.canRedo) { Icon(Icons.Default.Redo, "Redo") }
        IconButton({ save(pages, "organized") }, enabled = hist.canUndo) { Icon(Icons.Default.Save, "Save as new PDF") }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (sources.isEmpty()) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Reorder, rotate, duplicate, delete, extract or insert pages. Your original file is never changed.")
                    Spacer(Modifier.height(12.dp)); Button(pickMain) { Text("Choose PDF") }
                }
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ selected = pages.indices.toSet() }) { Text("Select all") }
                    TextButton({ selected = emptySet() }) { Text("Clear") }
                    Text("${selected.size} selected", style = MaterialTheme.typography.bodySmall)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
                    val has = sel.isNotEmpty()
                    ActionBtn(Icons.Default.RotateRight, "Rotate", has) { edit { l -> l.mapIndexed { i, p -> if (i in selected) p.copy(rot = (p.rot + 90) % 360) else p } } }
                    ActionBtn(Icons.Default.ContentCopy, "Duplicate", has) { edit { l -> l.flatMapIndexed { i, p -> if (i in selected) listOf(p, p) else listOf(p) } }; selected = emptySet() }
                    ActionBtn(Icons.Default.Delete, "Delete", has) { confirmDelete = true }
                    ActionBtn(Icons.Default.NoteAdd, "Blank page", true) {
                        val at = (sel.lastOrNull() ?: (pages.size - 1)) + 1
                        edit { l -> l.toMutableList().also { it.add(at, PageRef(-1, 0)) } }; selected = emptySet()
                    }
                    ActionBtn(Icons.Default.ArrowBack, "Move earlier", has && sel.first() > 0) {
                        edit { l -> l.toMutableList().also { m -> sel.forEach { i -> java.util.Collections.swap(m, i, i - 1) } } }; selected = sel.map { it - 1 }.toSet()
                    }
                    ActionBtn(Icons.Default.ArrowForward, "Move later", has && sel.last() < pages.size - 1) {
                        edit { l -> l.toMutableList().also { m -> sel.reversed().forEach { i -> java.util.Collections.swap(m, i, i + 1) } } }; selected = sel.map { it + 1 }.toSet()
                    }
                    ActionBtn(Icons.Default.FileCopy, "Extract", has) { save(sel.map { pages[it] }, "extracted") }
                    ActionBtn(Icons.Default.Add, "Add PDF", true, pickMore)
                }
                LazyVerticalGrid(GridCells.Adaptive(104.dp), Modifier.weight(1f), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(pages) { i, p ->
                        val on = i in selected
                        Column(Modifier.clickable { selected = if (on) selected - i else selected + i }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().aspectRatio(0.72f).background(Color.White)
                                .border(if (on) 3.dp else 1.dp, if (on) MaterialTheme.colorScheme.primary else Color.LightGray), contentAlignment = Alignment.Center) {
                                if (p.src < 0) Text("Blank", color = Color.Gray)
                                else {
                                    val s = sources[p.src]
                                    val bmp by produceState<Bitmap?>(null, p.src, p.idx) { value = try { BitmapCache.get(s, p.idx, 220) } catch (e: Exception) { null } }
                                    bmp?.let { Image(it.asImageBitmap(), "Page ${i + 1}", Modifier.fillMaxSize().rotate(p.rot.toFloat()), contentScale = ContentScale.Fit) }
                                }
                                if (on) Icon(Icons.Default.CheckCircle, "Selected", Modifier.align(Alignment.TopEnd), tint = MaterialTheme.colorScheme.primary)
                            }
                            Text("${i + 1}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
    if (confirmDelete) AlertDialog({ confirmDelete = false }, title = { Text(if (selected.size == 1) "Delete this page?" else "Delete ${selected.size} pages?") },
        text = { Text("They are removed from the new copy only; your original file is unchanged. You can undo this.") },
        confirmButton = { TextButton({ confirmDelete = false; edit { l -> l.filterIndexed { i, _ -> i !in selected } }; selected = emptySet() }) { Text("Delete") } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel") } })
    ToolHost(t)
    SavedDialog(flow) { nav.openPdf(it) }
}

@Composable
private fun ActionBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick, enabled = enabled) {
        Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(label)
    }
}
