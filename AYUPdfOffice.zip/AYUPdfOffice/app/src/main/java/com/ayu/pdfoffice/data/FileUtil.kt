package com.ayu.pdfoffice.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/** Storage Access Framework helpers. The app never asks for broad storage permission. */
object FileUtil {
    data class Meta(val name: String, val size: Long, val modified: Long)

    fun meta(ctx: Context, uri: Uri): Meta {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "document.pdf"
        var size = -1L
        var mod = 0L
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    c.getString(0)?.let { name = it }
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        } catch (_: Exception) {}
        try {
            ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) mod = c.getLong(0)
            }
        } catch (_: Exception) {}
        return Meta(name, size, mod)
    }

    fun safeName(n: String) = n.replace(Regex("[\\\\/:*?\"<>|]"), "_")

    /** Working copy: the original file is never modified by editing operations. */
    fun copyToCache(ctx: Context, uri: Uri, name: String): File {
        val dir = File(ctx.cacheDir, "docs/${uri.toString().hashCode().toUInt()}").apply { mkdirs() }
        val f = File(dir, safeName(name))
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Can't read this file.")
        input.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    fun newOut(ctx: Context, name: String): File {
        val dir = File(ctx.cacheDir, "out/${System.nanoTime()}").apply { mkdirs() }
        return File(dir, safeName(name))
    }

    fun copyTo(ctx: Context, file: File, uri: Uri) {
        val o = ctx.contentResolver.openOutputStream(uri, "wt") ?: throw IOException("Can't write to the chosen location.")
        o.use { out -> file.inputStream().use { it.copyTo(out) } }
    }

    fun persist(ctx: Context, uri: Uri) {
        val rw = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try { ctx.contentResolver.takePersistableUriPermission(uri, rw) }
        catch (_: Exception) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
    }

    fun size(b: Long): String = when {
        b < 0 -> "—"
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> "%.0f KB".format(b / 1024.0)
        else -> "%.1f MB".format(b / 1048576.0)
    }

    fun shareFile(ctx: Context, file: File, mime: String = "application/pdf") {
        shareUri(ctx, FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file), mime)
    }

    fun shareUri(ctx: Context, uri: Uri, mime: String = "application/pdf") {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, null))
    }

    /** Android print framework: the PDF bytes are streamed to the system print service. */
    fun print(ctx: Context, file: File, name: String) {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(name, object : PrintDocumentAdapter() {
            override fun onLayout(old: PrintAttributes?, new: PrintAttributes?, cancel: CancellationSignal?, cb: LayoutResultCallback, extras: Bundle?) {
                if (cancel?.isCanceled == true) { cb.onLayoutCancelled(); return }
                cb.onLayoutFinished(
                    PrintDocumentInfo.Builder(name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(), true)
            }
            override fun onWrite(pages: Array<out PageRange>?, dest: ParcelFileDescriptor, cancel: CancellationSignal?, cb: WriteResultCallback) {
                try {
                    FileInputStream(file).use { i -> FileOutputStream(dest.fileDescriptor).use { o -> i.copyTo(o) } }
                    cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) { cb.onWriteFailed(e.message) }
            }
        }, null)
    }
}

/** First-page thumbnails for the library lists, kept in the cache directory. */
object Thumbs {
    private fun f(ctx: Context, key: String) = File(ctx.cacheDir, "thumbs/${key.hashCode().toUInt()}.png")
    fun save(ctx: Context, key: String, bmp: Bitmap) {
        runCatching {
            val file = f(ctx, key); file.parentFile?.mkdirs()
            file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
        }
    }
    fun load(ctx: Context, key: String): Bitmap? =
        f(ctx, key).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
}
