@file:OptIn(ExperimentalMaterial3Api::class)
package com.ayu.pdfoffice.ui

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.navigation.NavHostController
import com.ayu.pdfoffice.data.FileUtil
import com.ayu.pdfoffice.data.Pending
import com.ayu.pdfoffice.data.Store
import com.ayu.pdfoffice.pdf.*
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun pdfName(s: String, fallback: String) = (s.trim().ifEmpty { fallback }).let { if (it.endsWith(".pdf", true)) it else "$it.pdf" }

// ------------------------------------------------------------------ Merge
private class MItem(val uri: Uri, val name: String, val file: File, val pages: Int)

@Composable
fun MergeScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    val items = remember { mutableStateListOf<MItem>() }
    var outName by remember { mutableStateOf("merged") }
    val flow = rememberSaveFlow(onError = { t.error = it })
    fun add(uris: List<Uri>) = t.exec("Adding files…", {
        uris.map { u ->
            val m = FileUtil.meta(ctx, u); val f = FileUtil.copyToCache(ctx, u, m.name)
            MItem(u, m.name, f, PdfOps.pageCount(f)) // throws for password-protected files
        }
    }) { items.addAll(it) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { FileUtil.persist(ctx, it) }; if (uris.isNotEmpty()) add(uris)
    }
    LaunchedEffect(Unit) { Pending.take()?.let { add(listOf(it)) } }
    ToolScaffold("Merge PDF", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            OutlinedButton({ picker.launch(arrayOf("application/pdf")) }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add PDFs") }
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(items) { i, m ->
                    val thumb by produceState<Bitmap?>(null, m.file) {
                        value = withContext(Dispatchers.IO) { runCatching { val s = PdfSource(m.file); try { s.render(0, 120) } finally { s.close() } }.getOrNull() }
                    }
                    ListItem(
                        leadingContent = { Box(Modifier.size(40.dp, 56.dp).background(Color.White)) { thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) } } },
                        headlineContent = { Text(m.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text("${m.pages} pages") },
                        trailingContent = {
                            Row {
                                IconButton({ if (i > 0) items.add(i - 1, items.removeAt(i)) }, enabled = i > 0) { Icon(Icons.Default.KeyboardArrowUp, "Move up") }
                                IconButton({ if (i < items.size - 1) items.add(i + 1, items.removeAt(i)) }, enabled = i < items.size - 1) { Icon(Icons.Default.KeyboardArrowDown, "Move down") }
                                IconButton({ items.removeAt(i) }) { Icon(Icons.Default.Close, "Remove") }
                            }
                        })
                }
            }
            OutlinedTextField(outName, { outName = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Output file name") })
            Spacer(Modifier.height(8.dp))
            Button({
                val files = items.map { it.file }
                t.exec("Merging…", { val out = FileUtil.newOut(ctx, pdfName(outName, "merged")); PdfOps.merge(files, out); out }) { flow.start(it) }
            }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = items.size >= 2) { Text("Merge (${items.sumOf { it.pages }} pages)") }
        }
    }
    ToolHost(t); SavedDialog(flow) { nav.openPdf(it) }
}

// ------------------------------------------------------------------ Split / extract
@Composable
fun SplitScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    var mode by remember { mutableIntStateOf(1) }
    var text by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("5") }
    var plan by remember { mutableStateOf<List<IntRange>?>(null) }
    var result by remember { mutableStateOf<String?>(null) }
    val flow = rememberSaveFlow(onError = { t.error = it })
    val pick = rememberPdfPicker { t.load(it) }
    LaunchedEffect(Unit) { Pending.take()?.let { t.load(it) } }
    val folder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val d = t.doc; val p = plan
        if (tree != null && d != null && p != null)
            t.exec("Splitting…", { PdfOps.splitToTree(ctx, d.file, p, tree, d.base) { t.progress = it } }) { result = "Created $it PDF file(s) in the chosen folder." }
    }
    ToolScaffold("Split PDF", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FileCard(t.doc, "No PDF selected") { pick() }
            ChipRow(listOf("Every page", "Page ranges", "Equal groups", "Extract pages"), mode) { mode = it }
            when (mode) {
                1 -> OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Ranges, e.g. 1-5, 6-10, 11-20") })
                2 -> OutlinedTextField(group, { group = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Pages per file") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                3 -> OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Pages to keep, e.g. 1-3, 7, 9-10") })
                else -> Text("Creates one PDF per page.")
            }
            Button({
                val d = t.doc ?: return@Button
                try {
                    val p = when (mode) {
                        0 -> (0 until d.pages).map { it..it }
                        1 -> Ranges.parse(text, d.pages)
                        2 -> Ranges.groups(d.pages, group.toIntOrNull() ?: 0)
                        else -> Ranges.parse(text, d.pages)
                    }
                    if (mode == 3) t.exec("Extracting…", { val out = FileUtil.newOut(ctx, "${d.base}_extract.pdf"); PdfOps.extract(d.file, p, out); out }) { flow.start(it) }
                    else { plan = p; folder.launch(null) }
                } catch (e: IllegalArgumentException) { t.error = e.message }
            }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = t.doc != null) { Text(if (mode == 3) "Extract" else "Split — choose folder") }
        }
    }
    result?.let { AlertDialog({ result = null }, { TextButton({ result = null }) { Text("OK") } }, title = { Text("Done") }, text = { Text(it) }) }
    ToolHost(t); SavedDialog(flow) { nav.openPdf(it) }
}

// ------------------------------------------------------------------ Compress
@Composable
fun CompressScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    var level by remember { mutableIntStateOf(Store.compression) }
    var out by remember { mutableStateOf<File?>(null) }
    var orig by remember { mutableLongStateOf(0L) }
    var note by remember { mutableStateOf<String?>(null) }
    val flow = rememberSaveFlow(onError = { t.error = it })
    val pick = rememberPdfPicker { out = null; note = null; t.load(it) }
    LaunchedEffect(Unit) { Pending.take()?.let { t.load(it) } }
    ToolScaffold("Compress PDF", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FileCard(t.doc, "No PDF selected") { pick() }
            ChipRow(listOf("Low (best quality)", "Medium", "High (smallest)"), level) { level = it; out = null; note = null }
            Text("Compression re-encodes large images. PDFs that are mostly text often can't be made smaller, and the original is never replaced.", style = MaterialTheme.typography.bodySmall)
            Button({
                val d = t.doc ?: return@Button
                orig = d.file.length()
                t.exec("Compressing…", {
                    val o = FileUtil.newOut(ctx, "${d.base}_compressed.pdf")
                    PdfOps.compress(d.file, o, Level.values()[level]) { p, n -> t.progress = p.toFloat() / n }
                    o
                }) { o ->
                    if (o.length() < orig) { out = o; note = null } else { out = null; note = "This PDF is already well optimised – no savings were possible, so nothing was created." }
                }
            }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = t.doc != null) { Text("Compress") }
            note?.let { Text(it) }
            out?.let { o ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Original size: ${FileUtil.size(orig)}"); Text("New size: ${FileUtil.size(o.length())}")
                        Text("Reduced by ${100 - (o.length() * 100 / orig)}%", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp)); Button({ flow.start(o) }) { Text("Save as new PDF") }
                    }
                }
            }
        }
    }
    ToolHost(t); SavedDialog(flow) { nav.openPdf(it) }
}

// ------------------------------------------------------------------ Protect / unlock
@Composable
fun ProtectScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    var tab by remember { mutableIntStateOf(0) }
    var user by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var current by remember { mutableStateOf("") }
    var pPrint by remember { mutableStateOf(true) }
    var pCopy by remember { mutableStateOf(true) }
    var pMod by remember { mutableStateOf(true) }
    var pAnn by remember { mutableStateOf(true) }
    val flow = rememberSaveFlow(onError = { t.error = it })
    val pick = rememberPdfPicker { t.load(it, allowLocked = true) }
    LaunchedEffect(Unit) { Pending.take()?.let { t.load(it, allowLocked = true) } }
    @Composable fun sw(label: String, v: Boolean, set: (Boolean) -> Unit) =
        Row(verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(v, set) }
    ToolScaffold("Protect PDF", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FileCard(t.doc, "No PDF selected") { pick() }
            TabRow(tab) { Tab(tab == 0, { tab = 0 }, text = { Text("Add password") }); Tab(tab == 1, { tab = 1 }, text = { Text("Remove security") }) }
            if (t.doc?.locked == true) OutlinedTextField(current, { current = it }, Modifier.fillMaxWidth(), label = { Text("Current password") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true)
            if (tab == 0) {
                OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label = { Text("Password to open (optional)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(owner, { owner = it }, Modifier.fillMaxWidth(), label = { Text("Owner password (to change permissions)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                Text("Allowed actions", style = MaterialTheme.typography.titleSmall)
                sw("Printing", pPrint) { pPrint = it }; sw("Copying text", pCopy) { pCopy = it }; sw("Editing", pMod) { pMod = it }; sw("Annotations", pAnn) { pAnn = it }
                Text("Uses AES-256 encryption. If you restrict actions, set an owner password. There is no way to recover a forgotten password.", style = MaterialTheme.typography.bodySmall)
                Button({
                    val d = t.doc ?: return@Button
                    t.exec("Encrypting…", { val o = FileUtil.newOut(ctx, "${d.base}_protected.pdf"); PdfOps.protect(d.file, o, current, user, owner, pPrint, pCopy, pMod, pAnn); o }) { flow.start(it) }
                }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = t.doc != null) { Text("Protect & save") }
            } else {
                Text("Removes the password from a copy. You must know the password – nothing is bypassed.", style = MaterialTheme.typography.bodySmall)
                Button({
                    val d = t.doc ?: return@Button
                    t.exec("Unlocking…", { val o = FileUtil.newOut(ctx, "${d.base}_unlocked.pdf"); PdfOps.removeSecurity(d.file, o, current); o }) { flow.start(it) }
                }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = t.doc != null) { Text("Remove security & save") }
            }
        }
    }
    ToolHost(t); SavedDialog(flow) { nav.openPdf(it) }
}

// ------------------------------------------------------------------ Watermark
@Composable
fun WatermarkScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    var text by remember { mutableStateOf("CONFIDENTIAL") }
    var size by remember { mutableFloatStateOf(60f) }
    var opacity by remember { mutableFloatStateOf(0.3f) }
    var rot by remember { mutableFloatStateOf(45f) }
    var color by remember { mutableIntStateOf(0xFFC62828.toInt()) }
    var pos by remember { mutableIntStateOf(0) }
    val flow = rememberSaveFlow(onError = { t.error = it })
    val pick = rememberPdfPicker { t.load(it) }
    LaunchedEffect(Unit) { Pending.take()?.let { t.load(it) } }
    ToolScaffold("Text watermark", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FileCard(t.doc, "No PDF selected") { pick() }
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Watermark text") })
            Text("Size: ${size.toInt()} pt"); Slider(size, { size = it }, valueRange = 12f..160f)
            Text("Opacity: ${(opacity * 100).toInt()}%"); Slider(opacity, { opacity = it }, valueRange = 0.05f..1f)
            Text("Rotation: ${rot.toInt()}°"); Slider(rot, { rot = it }, valueRange = -90f..90f)
            ColorDots(listOf(0xFFC62828, 0xFF1A237E, 0xFF2E7D32, 0xFF616161, 0xFF000000).map { it.toInt() }, color) { color = it }
            ChipRow(listOf("Center", "Top", "Bottom"), pos) { pos = it }
            Text("Font: Helvetica Bold (Latin text). Image watermarks aren't available in this build.", style = MaterialTheme.typography.bodySmall)
            Button({
                val d = t.doc ?: return@Button
                val o = WmOpts(text, size, opacity, rot, color, pos)
                t.exec("Adding watermark…", { val f = FileUtil.newOut(ctx, "${d.base}_watermarked.pdf"); PdfOps.watermark(d.file, f, o); f }) { flow.start(it) }
            }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = t.doc != null && text.isNotBlank()) { Text("Apply & save") }
        }
    }
    ToolHost(t); SavedDialog(flow) { nav.openPdf(it) }
}

// ------------------------------------------------------------------ Image -> PDF
@Composable
fun ImageToPdfScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    val imgs = remember { mutableStateListOf<Pair<Uri, Int>>() }
    var a4 by remember { mutableStateOf(true) }
    var outName by remember { mutableStateOf("images") }
    val flow = rememberSaveFlow(onError = { t.error = it })
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris -> uris.forEach { imgs.add(it to 0) } }
    ToolScaffold("Image → PDF", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            OutlinedButton({ picker.launch("image/*") }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text(if (imgs.isEmpty()) "Select images" else "Add more images") }
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(imgs) { i, (u, r) ->
                    val thumb by produceState<Bitmap?>(null, u, r) { value = withContext(Dispatchers.IO) { runCatching { PdfOps.decodeImage(ctx, u, 200, r) }.getOrNull() } }
                    ListItem(
                        leadingContent = { Box(Modifier.size(56.dp).background(Color.White)) { thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) } } },
                        headlineContent = { Text("Image ${i + 1}") },
                        trailingContent = {
                            Row {
                                IconButton({ imgs[i] = u to (r + 90) % 360 }) { Icon(Icons.Default.RotateRight, "Rotate") }
                                IconButton({ if (i > 0) imgs.add(i - 1, imgs.removeAt(i)) }, enabled = i > 0) { Icon(Icons.Default.KeyboardArrowUp, "Move up") }
                                IconButton({ if (i < imgs.size - 1) imgs.add(i + 1, imgs.removeAt(i)) }, enabled = i < imgs.size - 1) { Icon(Icons.Default.KeyboardArrowDown, "Move down") }
                                IconButton({ imgs.removeAt(i) }) { Icon(Icons.Default.Close, "Remove") }
                            }
                        })
                }
            }
            ChipRow(listOf("A4 page", "Fit to image"), if (a4) 0 else 1) { a4 = it == 0 }
            OutlinedTextField(outName, { outName = it }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true, label = { Text("Output file name") })
            Text("Need to crop or clean up photos first? Use Scan Document.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 4.dp))
            Button({
                val list = imgs.toList(); val a = a4
                t.exec("Creating PDF…", { val o = FileUtil.newOut(ctx, pdfName(outName, "images")); PdfOps.imagesToPdf(ctx, list, o, a) { t.progress = it }; o }) { flow.start(it) }
            }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = imgs.isNotEmpty()) { Text("Create PDF") }
        }
    }
    ToolHost(t); SavedDialog(flow) { nav.openPdf(it) }
}

// ------------------------------------------------------------------ PDF -> Image
@Composable
fun PdfToImageScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    var png by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    val pick = rememberPdfPicker { t.load(it) }
    LaunchedEffect(Unit) { Pending.take()?.let { t.load(it) } }
    val folder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val d = t.doc
        if (tree != null && d != null) t.exec("Exporting images…", { PdfOps.pdfToImages(ctx, d.file, tree, d.base, png) { t.progress = it } }) { result = "Saved $it image(s) to the chosen folder." }
    }
    ToolScaffold("PDF → Image", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FileCard(t.doc, "No PDF selected") { pick() }
            ChipRow(listOf("JPG", "PNG"), if (png) 1 else 0) { png = it == 1 }
            Text("Every page is saved as its own image file.", style = MaterialTheme.typography.bodySmall)
            Button({ folder.launch(null) }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = t.doc != null) { Text("Choose folder & export") }
        }
    }
    result?.let { AlertDialog({ result = null }, { TextButton({ result = null }) { Text("OK") } }, title = { Text("Done") }, text = { Text(it) }) }
    ToolHost(t)
}

// ------------------------------------------------------------------ PDF -> Text
@Composable
fun PdfToTextScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    val flow = rememberSaveFlow("text/plain", onError = { t.error = it })
    val pick = rememberPdfPicker { t.load(it) }
    LaunchedEffect(Unit) { Pending.take()?.let { t.load(it) } }
    ToolScaffold("PDF → Text", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FileCard(t.doc, "No PDF selected") { pick() }
            Text("Extracts selectable text only. Scanned pages have no text (OCR isn't included). Layout and formatting are not preserved.", style = MaterialTheme.typography.bodySmall)
            Button({
                val d = t.doc ?: return@Button
                t.exec("Extracting text…", { val o = FileUtil.newOut(ctx, "${d.base}.txt"); PdfOps.extractText(d.file, o); o }) { flow.start(it) }
            }, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = t.doc != null) { Text("Extract & save .txt") }
        }
    }
    ToolHost(t); SavedDialog(flow, null)
}

// ------------------------------------------------------------------ Scan
@Composable
fun ScanScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val t = rememberTool()
    val flow = rememberSaveFlow(onError = { t.error = it })
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val u = GmsDocumentScanningResult.fromActivityResultIntent(r.data)?.pdf?.uri
            if (u != null) t.exec("Preparing PDF…", {
                val o = FileUtil.newOut(ctx, "Scan_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.pdf")
                val i = ctx.contentResolver.openInputStream(u) ?: throw PdfError("Couldn't read the scan.")
                i.use { s -> o.outputStream().use { s.copyTo(it) } }
                o
            }) { flow.start(it) }
        }
    }
    ToolScaffold("Scan document", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Uses the on-device Google document scanner: camera capture, automatic edge detection, crop, rotate, perspective correction, brightness/contrast, grayscale / black & white, and multi-page scanning. Images are processed on your phone and are not uploaded.")
            Text("Requires Google Play services. If your device doesn't have it, scanning is unavailable – use Image → PDF instead.", style = MaterialTheme.typography.bodySmall)
            Button({
                val act = ctx.activity() ?: return@Button
                val opts = GmsDocumentScannerOptions.Builder().setGalleryImportAllowed(true).setPageLimit(50)
                    .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF).setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL).build()
                GmsDocumentScanning.getClient(opts).getStartScanIntent(act)
                    .addOnSuccessListener { launcher.launch(IntentSenderRequest.Builder(it).build()) }
                    .addOnFailureListener { t.error = "The document scanner isn't available on this device (it needs Google Play services). ${it.message ?: ""}" }
            }, Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Icon(Icons.Default.DocumentScanner, null); Spacer(Modifier.width(8.dp)); Text("Start scanning") }
        }
    }
    ToolHost(t); SavedDialog(flow) { nav.openPdf(it) }
}

// ------------------------------------------------------------------ Convert hub
@Composable
fun ConvertScreen(nav: NavHostController) {
    var info by remember { mutableStateOf<String?>(null) }
    ToolScaffold("Convert", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad)) {
            ListItem(headlineContent = { Text("PDF → Image (JPG / PNG)") }, leadingContent = { Icon(Icons.Default.PhotoLibrary, null) }, modifier = Modifier.clickableRow { nav.navigate("pdf2img") })
            ListItem(headlineContent = { Text("Image → PDF") }, leadingContent = { Icon(Icons.Default.Image, null) }, modifier = Modifier.clickableRow { nav.navigate("img2pdf") })
            ListItem(headlineContent = { Text("PDF → Text") }, supportingContent = { Text("Selectable text only; formatting is not preserved") }, leadingContent = { Icon(Icons.Default.TextFields, null) }, modifier = Modifier.clickableRow { nav.navigate("pdf2text") })
            ListItem(headlineContent = { Text("PDF → Word (unavailable)") }, leadingContent = { Icon(Icons.Default.Description, null) }, modifier = Modifier.clickableRow { info = NO_ENGINE })
            ListItem(headlineContent = { Text("Word → PDF (unavailable)") }, leadingContent = { Icon(Icons.Default.PictureAsPdf, null) }, modifier = Modifier.clickableRow { info = NO_ENGINE })
        }
    }
    info?.let { AlertDialog({ info = null }, { TextButton({ info = null }) { Text("OK") } }, title = { Text("Not available") }, text = { Text(it) }) }
}

private fun Modifier.clickableRow(onClick: () -> Unit): Modifier = this.then(Modifier.clickable(onClick = onClick))
