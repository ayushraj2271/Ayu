package com.ayu.pdfoffice.ui

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ayu.pdfoffice.Incoming
import com.ayu.pdfoffice.data.Store

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val start = remember { if (Store.onboarded) "main" else "welcome" }
    LaunchedEffect(Incoming.uri) { Incoming.uri?.let { nav.openPdf(it); Incoming.uri = null } }
    NavHost(nav, startDestination = start) {
        composable("welcome") {
            WelcomeScreen { Store.finishOnboarding(); nav.navigate("main") { popUpTo("welcome") { inclusive = true } } }
        }
        composable("main") { MainScreen(nav) }
        composable("viewer/{uri}") { ViewerScreen(Uri.parse(it.arguments!!.getString("uri")!!), nav) }
        composable("editor/{mode}") { EditorScreen(nav, it.arguments!!.getString("mode")!!) }
        composable("organize") { OrganizerScreen(nav) }
        composable("merge") { MergeScreen(nav) }
        composable("split") { SplitScreen(nav) }
        composable("compress") { CompressScreen(nav) }
        composable("protect") { ProtectScreen(nav) }
        composable("watermark") { WatermarkScreen(nav) }
        composable("img2pdf") { ImageToPdfScreen(nav) }
        composable("pdf2img") { PdfToImageScreen(nav) }
        composable("pdf2text") { PdfToTextScreen(nav) }
        composable("scan") { ScanScreen(nav) }
        composable("convert") { ConvertScreen(nav) }
        composable("info/{page}") { InfoScreen(nav, it.arguments!!.getString("page")!!) }
    }
}
