package com.ayu.pdfoffice.pdf

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Page-range parsing shared by Split / Extract. Pages are 1-based for users, 0-based in results. */
object Ranges {
    private val part = Regex("""^(\d+)\s*(?:-\s*(\d+))?$""")

    fun parse(text: String, pageCount: Int): List<IntRange> {
        val out = mutableListOf<IntRange>()
        for (raw in text.split(',', ';')) {
            val p = raw.trim()
            if (p.isEmpty()) continue
            val m = part.matchEntire(p) ?: throw IllegalArgumentException("Can't read \"$p\". Use a format like 1-5, 8, 10-12.")
            val a = m.groupValues[1].toInt()
            val b = (m.groupValues[2].ifEmpty { m.groupValues[1] }).toInt()
            require(a in 1..pageCount && b in 1..pageCount && a <= b) { "\"$p\" is outside 1–$pageCount." }
            out.add((a - 1)..(b - 1))
        }
        require(out.isNotEmpty()) { "Enter at least one page range." }
        return out
    }

    fun groups(pageCount: Int, size: Int): List<IntRange> {
        require(size >= 1) { "Group size must be at least 1." }
        return (0 until pageCount step size).map { it until minOf(it + size, pageCount) }
    }
}

/** Snapshot-based undo/redo. T must be an immutable value (e.g. List). */
class History<T>(initial: T) {
    private val undoS = ArrayList<T>()
    private val redoS = ArrayList<T>()
    var current by mutableStateOf(initial)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    fun push(v: T) {
        undoS.add(current)
        if (undoS.size > 200) undoS.removeAt(0)
        redoS.clear()
        current = v
        sync()
    }
    fun undo() { if (undoS.isEmpty()) return; redoS.add(current); current = undoS.removeAt(undoS.lastIndex); sync() }
    fun redo() { if (redoS.isEmpty()) return; undoS.add(current); current = redoS.removeAt(redoS.lastIndex); sync() }
    private fun sync() { canUndo = undoS.isNotEmpty(); canRedo = redoS.isNotEmpty() }
}
