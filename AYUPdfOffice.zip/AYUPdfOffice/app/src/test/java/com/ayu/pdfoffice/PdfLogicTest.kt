package com.ayu.pdfoffice

import com.ayu.pdfoffice.pdf.History
import com.ayu.pdfoffice.pdf.Ranges
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class PdfLogicTest {
    @Test fun parsesRanges() {
        assertEquals(listOf(0..4, 5..9, 10..19), Ranges.parse("1-5, 6-10, 11-20", 20))
        assertEquals(listOf(2..2, 6..8), Ranges.parse("3; 7-9", 20))
    }
    @Test fun rejectsBadRanges() {
        for (bad in listOf("0-3", "5-2", "1-99", "abc", "")) {
            try { Ranges.parse(bad, 20); fail("should reject: $bad") } catch (e: IllegalArgumentException) { }
        }
    }
    @Test fun equalGroups() {
        assertEquals(listOf(0..4, 5..9, 10..11), Ranges.groups(12, 5))
        assertEquals(1, Ranges.groups(3, 10).size)
    }
    @Test fun undoRedo() {
        val h = History(listOf(1))
        h.push(listOf(1, 2)); h.push(listOf(1, 2, 3))
        assertTrue(h.canUndo); assertFalse(h.canRedo)
        h.undo(); assertEquals(listOf(1, 2), h.current); assertTrue(h.canRedo)
        h.redo(); assertEquals(listOf(1, 2, 3), h.current)
        h.undo(); h.push(listOf(9)); assertFalse(h.canRedo) // new edit clears redo
    }
}
