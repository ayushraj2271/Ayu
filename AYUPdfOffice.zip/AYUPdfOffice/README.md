# AYU PDF Office (native Android, Kotlin + Jetpack Compose)

Your PDF. Your Documents. Your Control.

## Build
1. Install Android Studio (Koala or newer, JDK 17). Open this folder (`File ▸ Open`). Let Gradle sync
   (needs internet once to download dependencies; the app itself needs none).
   If the wrapper jar is missing run `gradle wrapper --gradle-version 8.9` or accept Studio's prompt.
2. Debug APK: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
3. Release: create `keystore.properties` in the project root
   (`storeFile=/abs/path/key.jks`, `storePassword=`, `keyAlias=`, `keyPassword=`), then
   `./gradlew assembleRelease` (APK) and `./gradlew bundleRelease` (AAB, `app/build/outputs/bundle/release/`).
   Rename the outputs to "AYU PDF Office.apk / .aab" if desired.
4. Unit tests: `./gradlew testDebugUnitTest` (page-range parsing, undo/redo).

> STATUS: this source was written without access to the Android SDK or Maven, so it has NOT been
> compiled or run yet. Expect a few first-build fixes (versions/imports). Test on a real phone with
> the PDFs listed in the spec (1, 50, 500 pages, image-heavy, scanned, large) before release.

## Architecture
- `data/` – SharedPreferences store (settings, recent library, bookmarks), SAF/file/share/print helpers
- `pdf/` – `PdfSource` (Android PdfRenderer, lazy per-page rendering + LRU cache), `PdfOps` (PdfBox-Android:
  merge, split, organize, compress, protect, watermark, redact, text extraction), `Overlay` (annotation model + geometry)
- `ui/` – Compose screens: Home/Files/Tools/Recent/Settings, Viewer, Editor, Organizer, tool screens

Rendering, editing and conversion are separate objects so each can be swapped independently.

## Feature status (nothing is simulated)
Implemented: viewer (zoom, thumbnails, search, bookmarks, go-to, rotate, full screen, dark reading, print, share, save copy),
annotate/sign/fill (text, pen, highlight area, rectangle, signature draw/type/import, check, cross, date, image, undo/redo),
true redaction (page rasterized), organizer (rotate, delete, duplicate, blank page, move, extract, add PDF, undo/redo),
merge, split (every page / ranges / equal groups / extract), compress (image re-encoding, honest size report),
password + permissions (AES-256), remove security (password required), text watermark, image→PDF, PDF→image,
PDF→text, scanner (ML Kit on-device), file list with rename/share/favorite/details/delete, themes, first launch, privacy.

Not available in this build (hidden or disabled with an explanation): PDF↔Word, image watermark, editing existing text,
text-anchored highlight/underline/strikethrough, sticky notes, drag-and-drop page reorder, pinch-zoom inside the editor,
cryptographic digital signatures (signatures are visual only), autosave/crash restore (edits are in memory and only ever
saved to new files), app lock, overwrite-original, move/copy files, OCR, content search across files, Documents/Images/
Spreadsheets/Presentations categories.
